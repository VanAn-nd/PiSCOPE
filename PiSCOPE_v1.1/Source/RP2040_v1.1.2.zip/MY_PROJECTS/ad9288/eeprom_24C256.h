#ifndef EEPROM_24C256_H
#define EEPROM_24C256_H

#include "hardware/i2c.h"
#include <stdint.h>
#include <stdbool.h>


#define EEPROM_I2C_PORT       i2c0
#define EEPROM_I2C_ADDR       0x50
#define EEPROM_SDA_PIN        20
#define EEPROM_SCL_PIN        21

#define MARKER_PENDING   0x7E
#define MARKER_COMMITTED 0x2C //A5
#define MARKER_EMPTY     0xFF

#define CALIB_BASE  0x0000
#define CONFIG_BASE 0x0038

typedef struct __attribute__((packed)){
    uint8_t  marker;      // =0xFF/0x7E/0x2C
    uint8_t  id;          // ID cấu hình (0..255)
    uint8_t  data;        // 1 byte dữ liệu config
    uint16_t sequence;    // counter
    uint8_t  checksum;    // CRC8 của 5 byte trên
} ConfigBlock;

#define EEPROM_SIZE 32768        // tổng dung lượng EEPROM 24C256 = 32KB
#define BLOCK_SIZE sizeof(ConfigBlock) // magic + config_id + data + crc
#define config_array_size 13 
#define MAX_BLOCKS (EEPROM_SIZE / BLOCK_SIZE)


void eeprom_init();
bool eeprom_read_bytes(uint16_t addr, uint8_t *buffer, size_t len);  //OK
bool eeprom_write_bytes(uint16_t addr, const uint8_t *data, size_t len);  //OK
uint8_t crc8(const uint8_t *data, size_t len);
bool eeprom_read_config_byte(uint16_t addr, uint8_t *config_id, uint8_t *data); 
bool eeprom_write_config_byte(uint16_t addr, uint8_t config_id, uint8_t data);
bool eeprom_read_all_configs(uint8_t configs[config_array_size]);
uint16_t eeprom_write_new_block(uint8_t config_id, uint8_t data);
uint16_t eeprom_wl_init(uint8_t configs[config_array_size]);



#endif