/**
 * Copyright (c) 2020 Raspberry Pi (Trading) Ltd.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "pico/stdlib.h"
#include <stdio.h>
#include "hardware/adc.h"
#include "hardware/dma.h"
#include "hardware/pio.h"
#include "hardware/clocks.h"
#include "hardware/flash.h"
#include "hardware/spi.h"
#include <pico/time.h>
#include "hardware/structs/systick.h"
#include "hardware/irq.h"
#include "hardware/i2c.h"
#include "pico/multicore.h"
#include "hardware/structs/bus_ctrl.h"
#include "capture.pio.h"
#include "LCD.h"
#include "eeprom_24C256.h"
#include "fft.h"
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "stdio.h"
#include <math.h>
//#include "arm_math.h"
//#include "arm_const_structs.h"

//#define CAT9555     //else PCF8575
//#define RP2350      //else RP2040
#define VERSION_1_1 //else VERSION_1_0

#define M_PI 3.14159265358979323846
#define TFT_WIDTH         ((uint16_t)320)
#define TFT_HEIGHT		  ((uint16_t)240)
#define GRID_WIDTH		  ((uint16_t)300)
#define GRID_HEIGHT		  ((uint16_t)200)
#define A1 					      0
#define A2 					      1

#define ACQ_SAMPLE     0
#define ACQ_PEAKDETECT 1
#define ACQ_AVERAGE    2


#define NUM_BUTTONS 16
// ENCODER
#define ENCODER1_A    (1 << 1)   // P1
#define ENCODER1_B    (1 << 0)   // P0
#define ENCODER2_A    (1 << 2)   // P2
#define ENCODER2_B    (1 << 3)   // P3
#define ENCODER2_SW   (1 << 4)   // P4

// DIRECTION BUTTONS
#define BTN_UP        (1 << 13)  // P13.
#define BTN_DWN       (1 << 11)  // P11.
#define BTN_LEFT      (1 << 10)  // P10.
#define BTN_RIGHT     (1 << 15)  // P15.
#define BTN_CTR       (1 << 12)  // P12.

// SWITCHES
#define SW1           (1 << 9)   // P9.
#define SW2           (1 << 7)   // P7.
#define SW3           (1 << 5)   // P5.
#define SW4           (1 << 8)   // P8.
#define SW5           (1 << 14)  // P14.
#define SW6           (1 << 6)   // P6.


#define BT_PRESSED_SHORT  100
#define BT_PRESSED_LONG  120
#define BT_HOLD 1800
#define BT_INCREMENT 400

#ifdef VERSION_1_1
#define CH1_x10 (1<<6)
#define CH1_DC  (1<<7)
#define CH1_AC  (0<<7)

#define CH2_x10 (1<<5)
#define CH2_DC  (1<<4)
#define CH2_AC  (0<<4)
#else //VERSION_1_0
#define CH1_x10 (1<<1)
#define CH1_DC  (1<<0)
#define CH1_AC  (0<<0)

#define CH2_x10 (1<<3)
#define CH2_DC  (1<<1)
#define CH2_AC  (0<<1)
#endif

#define CH1    1
#define CH2    2

critical_section_t my_lock;

#define clamp(val, min_val, max_val) (((val) < (min_val)) ? (min_val) : ((val) > (max_val)) ? (max_val) : (val))

// Biến dành riêng cho core0 (scratch_x)
//__attribute__((section(".scratch_x.mysection")))

PIO pio = pio0;
uint sm = 0;
uint dma_chan1 = 0, dma_chan2 = 1;
uint offset = 0, offset10 = 0, offset100 = 0, offset1000 = 0;

uint8_t reverse_lookup[256] = {
    0x00, 0x80, 0x40, 0xC0, 0x20, 0xA0, 0x60, 0xE0,
    0x10, 0x90, 0x50, 0xD0, 0x30, 0xB0, 0x70, 0xF0,
    0x08, 0x88, 0x48, 0xC8, 0x28, 0xA8, 0x68, 0xE8,
    0x18, 0x98, 0x58, 0xD8, 0x38, 0xB8, 0x78, 0xF8,
    0x04, 0x84, 0x44, 0xC4, 0x24, 0xA4, 0x64, 0xE4,
    0x14, 0x94, 0x54, 0xD4, 0x34, 0xB4, 0x74, 0xF4,
    0x0C, 0x8C, 0x4C, 0xCC, 0x2C, 0xAC, 0x6C, 0xEC,
    0x1C, 0x9C, 0x5C, 0xDC, 0x3C, 0xBC, 0x7C, 0xFC,
    0x02, 0x82, 0x42, 0xC2, 0x22, 0xA2, 0x62, 0xE2,
    0x12, 0x92, 0x52, 0xD2, 0x32, 0xB2, 0x72, 0xF2,
    0x0A, 0x8A, 0x4A, 0xCA, 0x2A, 0xAA, 0x6A, 0xEA,
    0x1A, 0x9A, 0x5A, 0xDA, 0x3A, 0xBA, 0x7A, 0xFA,
    0x06, 0x86, 0x46, 0xC6, 0x26, 0xA6, 0x66, 0xE6,
    0x16, 0x96, 0x56, 0xD6, 0x36, 0xB6, 0x76, 0xF6,
    0x0E, 0x8E, 0x4E, 0xCE, 0x2E, 0xAE, 0x6E, 0xEE,
    0x1E, 0x9E, 0x5E, 0xDE, 0x3E, 0xBE, 0x7E, 0xFE,
    0x01, 0x81, 0x41, 0xC1, 0x21, 0xA1, 0x61, 0xE1,
    0x11, 0x91, 0x51, 0xD1, 0x31, 0xB1, 0x71, 0xF1,
    0x09, 0x89, 0x49, 0xC9, 0x29, 0xA9, 0x69, 0xE9,
    0x19, 0x99, 0x59, 0xD9, 0x39, 0xB9, 0x79, 0xF9,
    0x05, 0x85, 0x45, 0xC5, 0x25, 0xA5, 0x65, 0xE5,
    0x15, 0x95, 0x55, 0xD5, 0x35, 0xB5, 0x75, 0xF5,
    0x0D, 0x8D, 0x4D, 0xCD, 0x2D, 0xAD, 0x6D, 0xED,
    0x1D, 0x9D, 0x5D, 0xDD, 0x3D, 0xBD, 0x7D, 0xFD,
    0x03, 0x83, 0x43, 0xC3, 0x23, 0xA3, 0x63, 0xE3,
    0x13, 0x93, 0x53, 0xD3, 0x33, 0xB3, 0x73, 0xF3,
    0x0B, 0x8B, 0x4B, 0xCB, 0x2B, 0xAB, 0x6B, 0xEB,
    0x1B, 0x9B, 0x5B, 0xDB, 0x3B, 0xBB, 0x7B, 0xFB,
    0x07, 0x87, 0x47, 0xC7, 0x27, 0xA7, 0x67, 0xE7,
    0x17, 0x97, 0x57, 0xD7, 0x37, 0xB7, 0x77, 0xF7,
    0x0F, 0x8F, 0x4F, 0xCF, 0x2F, 0xAF, 0x6F, 0xEF,
    0x1F, 0x9F, 0x5F, 0xDF, 0x3F, 0xBF, 0x7F, 0xFF
};
uint8_t reverse_lut[256] = {
    255, 254, 253, 252, 251, 250, 249, 248,
    247, 246, 245, 244, 243, 242, 241, 240,
    239, 238, 237, 236, 235, 234, 233, 232,
    231, 230, 229, 228, 227, 226, 225, 224,
    223, 222, 221, 220, 219, 218, 217, 216,
    215, 214, 213, 212, 211, 210, 209, 208,
    207, 206, 205, 204, 203, 202, 201, 200,
    199, 198, 197, 196, 195, 194, 193, 192,
    191, 190, 189, 188, 187, 186, 185, 184,
    183, 182, 181, 180, 179, 178, 177, 176,
    175, 174, 173, 172, 171, 170, 169, 168,
    167, 166, 165, 164, 163, 162, 161, 160,
    159, 158, 157, 156, 155, 154, 153, 152,
    151, 150, 149, 148, 147, 146, 145, 144,
    143, 142, 141, 140, 139, 138, 137, 136,
    135, 134, 133, 132, 131, 130, 129, 128,
    127, 126, 125, 124, 123, 122, 121, 120,
    119, 118, 117, 116, 115, 114, 113, 112,
    111, 110, 109, 108, 107, 106, 105, 104,
    103, 102, 101, 100,  99,  98,  97,  96,
     95,  94,  93,  92,  91,  90,  89,  88,
     87,  86,  85,  84,  83,  82,  81,  80,
     79,  78,  77,  76,  75,  74,  73,  72,
     71,  70,  69,  68,  67,  66,  65,  64,
     63,  62,  61,  60,  59,  58,  57,  56,
     55,  54,  53,  52,  51,  50,  49,  48,
     47,  46,  45,  44,  43,  42,  41,  40,
     39,  38,  37,  36,  35,  34,  33,  32,
     31,  30,  29,  28,  27,  26,  25,  24,
     23,  22,  21,  20,  19,  18,  17,  16,
     15,  14,  13,  12,  11,  10,   9,   8,
      7,   6,   5,   4,   3,   2,   1,   0
};

#define BUFFER_SIZE 		  32768
const uint CAPTURE_N_SAMPLES = 32768;
const uint CAPTURE_DATA_BASE = 0;
const uint CAPTURE_CLK_BASE = 26;
const uint CAPTURE_PIN_COUNT = 16;

uint16_t dynamic_size = 32768;

static inline uint bits_packed_per_word(uint pin_count) {  //adc
    const uint SHIFT_REG_WIDTH = 32;
    return SHIFT_REG_WIDTH - (SHIFT_REG_WIDTH % pin_count);
}
typedef struct
{
	uint32_t u32_tick_count;
}sys_timer;
sys_timer systick;
typedef struct Stats {
	int count;
	int duty;
	float freq;
	float cycle;
	double Vmaxf;
	double Vminf;
} t_Stats;
t_Stats  Stats;

typedef struct FFT {
	int count;
	double tdh;
	double sfdr;
	float freq;
} t_FFT;
t_FFT  FFT;

uint8_t  hOffset = (TFT_WIDTH - GRID_WIDTH)/2,
         Hold_old =0,
		 prepare_mode_change=0,
         old_zeropos_A1=150,old_zeropos_A2=150,
		 auto_trigger=0,
		 over_sample=1,
		 ch1Capture[BUFFER_SIZE], ch2Capture[BUFFER_SIZE];
float	 peakA1, peakA2, peakB1, peakB2;
uint16_t zeroVoltageA1 = 128, zeroVoltageA2 = 128, //0V
         ch1Capture_zoom[250],ch2Capture_zoom[250],
         trigger_color=0,
         trigger_point,
         Stats_color=0,
		 trigger_extra_point=0,
		 deo_biet_tai_sao=25,
         Index=0,
		 moveIndex=0;
volatile uint16_t TRGGcounter=0;
uint32_t check = 0, holdoff = 0;
volatile int16_t val1, val2,
				 trigger_pos=0,
				 tgadc=127,
				 trigger_pos_t=0,
				 tgpx=0,  //-150px 0(centerwindown) +150px
				 old_tgpx=0,
				 trigger_pos_drawing=0,
				 trigger_pos_y=100, //inPixel = 0 -> 100 -> GRID_HEIGHT
				 old_trigger_pos_y=0,
                 yCursors[2] = {100,100};
volatile int32_t xCursor=0;
volatile uint8_t trigger_pos_Y=0,
	             Stats_source =1,//1=CH1; 2=CH2;
                 Hold =0, hold_status=5,
                 Bt_pressed=1,
                 trigger_source = 1,  //CH1_UP=3; CH1_DWN=1; CH2_UP=4; CH2_DWN=2;
                 vOffset = (TFT_HEIGHT - GRID_HEIGHT)/2,
				//CH1+CH2=1;  CH1=2;  CH2=3;
                 show_mode=100,
                 position_wave=0,
                 conversion_ready=0,data_flag=0,
                 XY_MODE=0, //0-1
				 XY_MODE_OLD=0,
                 Legh_data=2,// 1:256pt:     2:512pt;     3:768pt;    4:1024pt  5:1280pt  6:1536pt  7:1792pt  8:2048pt
                 MENU=1,
				 MODE=1,
				 range_cursor= CH1,  //Enc_SW cursor: 1=CH1, 2=CH2
				 CH1_Opto=0, CH2_Opto=0
				 ; //1-2-3
const  float timebaseValue[] = {  0.2,       //ms/div
								0.1,
								0.05,
								0.02,
								0.01,
								0.005,
								0.002,
								0.001,
								0.5e-3,
								0.2e-3,
								0.1e-3,  //20  100us
								0.5e-4,
								0.2e-4,
								0.1e-4,
								0.5e-5,
								0.2e-5,
								0.1e-5,
								0.5e-6,
								0.2e-6,     //ADC speed 125Msps
								0.1e-6,
								0.5e-7};
const float PX_SCALE[] = {	1000000,
							500000,
							250000,
							100000,
							50000,
							25000,
							10000,
							5000,
							2500,
							1000,
							500,
							250,
							100,
							50,
							25,
							10,
							5,
							2.5,
							1,   //200ns = 18
							0.5, //100ns 
							0.25,// 50ns
							0.1, // 20ns
							0.05,// 10ns  = 22
							0.025// 5ns  = 23
							};
const uint8_t Over_Samples[] = {20,20,20,20,20,20,20,20,20,20,20,10,10,5,5,2,2,1,1,1,1,1,1,1};

uint16_t Z_offset1[] = {1024,1024,1024,1024,1024,1024,1024};//982
uint16_t Z_offset2[] = {1024,1024,1024,1024,1024,1024,1024};

uint8_t Vbase_fullscale1[] = {250,250,250,250,250,250,250};
uint8_t Vbase_fullscale2[] = {250,250,250,250,250,250,250};

int timebase_table[] = {1000000,1000000,1000000,1000000,1000000,1000000,1000000,1000000,1000000,1000000,2000000,4000000,10000000,20000000,40000000,100000000,100000000,10000000,100000000,100000000,100000000};
    //                                                                                         200us   100us   50us     20us     10us     5us       2us      1us      500ns    200ns     
volatile int timebase=18,  // Time base index 0-18
			 timebase_old,
			 smp_Range,  // ADC Range base
			 volbase1=3,  // Vol base index channel 1: 0-6
			 volbase2=3,  // Vol base index channel 2: 0-6
			 vRange_change=100; // Flag for button change timebase

volatile float   tgvol1=0,tgvol2=0;	 //inVoltage = -vol -> 0V -> +vol
#define PixelPerDIV 25.0  //20 Pixel per DIV
const float      VolPerDIV[7] = {0.1,0.2,0.5,1.0,2.0,5.0,10.0};
static int16_t yCursorsSnap[2],yCursorsOld[2];
static bool wavesSnap[2],wavesOld[2] = {false,false};
uint8_t LCD_Buffer[2*(200+1)];

bool write_ping = true;
static volatile int adc_buf1_counter = 0;
static volatile int adc_buf2_counter = 0;
static volatile int other_counter = 0;
//#define PING_PONG
static uint16_t adc_buf[BUFFER_SIZE]__attribute__((aligned(BUFFER_SIZE))) = {0};
#ifdef PING_PONG
static uint16_t capture_buf2[BUFFER_SIZE]__attribute__((aligned(BUFFER_SIZE))) = {0};
#endif
uint16_t *read_addr;
void *write_addr;
float virIndex=0, old_virIndex, scale;
float Bvol=0;
uint16_t IDE=0;
int16_t old_pix=0;

uint32_t cnt = 0;
uint8_t battery[2]={0x00,0x00};

bool eeprom_flag = false;
uint8_t config_id = 0;
uint16_t event=0;
uint16_t dia_chi=0x0000;

uint8_t calib_mode = 0;
bool calib_cursor=false;
char zcalib[5];
char vcalib[4];
bool Save_calib = false;
bool Acquisition = false;


#ifdef RP2350
#define  N 4096
#else
#define  N 1024
#endif

float peakMag;
uint8_t window_type=0;
uint8_t skip=1;
bool clear=false;
uint8_t FFT_CH=1;
bool OSC=true;
const int sampling_rate[]={120, 240, 600, 1200,2400,6000,12000,24000,60000,120000,240000,600000,1200000,2400000,6000000,12000000,24000000,60000000,120000000};
uint32_t id_old=0; 

const char* const TIMEBASE_STRINGS[] = {
    "200ms", "100ms", "50ms ", "20ms ", "10ms ", "5ms  ", "2ms  ", "1ms  ",
    "500us", "200us", "100us", "50us ", "20us ", "10us ", "5us  ", "2us  ",
    "1us  ", "500ns", "200ns", "100ns", "50ns ", "20ns ", "10ns ", "5ns  "
};

char lb00[20], lb01[20], lb02[20], lb10[20], lb11[20], lb12[20];

const char* const VOLTAGE_STRINGS[] = {
    "0.1V ", "0.2V ", "0.5V ", " 1V ", " 2V ", " 5V ", " 10V"
};

const char* const FFT_TIMEBASE_STRINGS[] = {
    "   5Hz    120S/s ", "  10Hz    240S/s ", "  25Hz    600S/s ", "  50Hz   1.2kS/s ",
    " 100Hz   2.4kS/s ", " 250Hz     6kS/s ", " 500Hz    12kS/s ", "  1kHz    24kS/s ",
    "2.5kHz    60kS/s ", "  5kHz   120kS/s ", " 10kHz   240kS/s ", " 25kHz   600kS/s ",
    " 50kHz   1.2MS/s ", "100kHz   2.4MS/s ", "250kHz     6MS/s ", "500kHz    12MS/s ",
    "  1MHz    24MS/s ", "2.5MHz    60MS/s ", "  5MHz   120MS/s "
};

const char* const FFT_WINDOW_STRINGS[] = {
    "Rectangular",
	"    HFT248D",
	"BlackmanHar",
	"    Flattop",
	"    Hanning"
};

#define MOVING_AVG_SIZE 5
#define MAX_CYCLES 50


volatile int start_sample, end_sample;


int sum3(int k) {       // Sum of before and after and own value
	int m=0;
	if (Stats_source==1) {m = ch1Capture[k - 1] + ch1Capture[k] + ch1Capture[k + 1];}
	else                 {m = ch2Capture[k - 1] + ch2Capture[k] + ch2Capture[k + 1];}
 	return m;
}

void GRID_MARK(uint16_t i);
void DRAW_STATS_WAVE(void);
void WAVE_INFO_CALCULATOR(uint8_t over_sample);
void MARSK_SCREEN(void);
void DRAW_WAVE_POS_ICON(void);
void DRAW_WAVE(uint16_t start_index, uint8_t over_sample);
void SEARCH_TRIGGER_POINT(uint8_t over_sample);
void SET_FREQ_ADC(uint freq);
void DRAW_TRIGG_PosXY(void);
void DRAW_TRIGGER_ICON(void);
void DRAW_PANEL(uint16_t x, uint16_t y, uint16_t bgr);
uint16_t PCF8575_readButton16();
uint16_t FAST_TRIGGER(uint16_t* buffer, uint8_t channel, uint8_t over_sample);
uint8_t BIT_REVERSE (uint16_t value, uint8_t ch);
void process_buttons(uint16_t button);
void handle_button_short_press(uint16_t button);
void handle_button_long_press(uint8_t button);
uint8_t movingAvg(uint8_t* buffer, int pos, int length);
int cmp_float(const void* a, const void* b);
void RenderLabels(uint16_t pos);
void save_calibration_data(void);
void load_calibration_data(void);
void DRAW_FFT(void);
void DRAW_FFT_info(void);
int refine_trigger_around(uint8_t *buffer, uint32_t size, uint16_t tgadc, int index, int over_sample, bool rising_edge, int range_multiple);
float sinc_interpolate_uint8(const uint8_t *samples, int num_samples, float t_ns);

uint16_t button_mask[NUM_BUTTONS] = {
    1 << 0, 1 << 1, 1 << 2, 1 << 3, 1 << 4, 1 << 5, 1 << 6, 1 << 7, 1 << 8, 1 << 9, 1 << 10, 1 << 11, 1 << 12, 1 << 13, 1 << 14,1 << 15
};

extern void isr_systick() //Rewrite of weak systick IRQ in crt0.s file
{
	systick.u32_tick_count++;     
}

void dma_handler() {
    // Clear the interrupt request.
    dma_hw->ints0 = 1u << dma_chan1;
    
	#ifdef PING_PONG
	if (write_ping) {
        // Ping was being written to, and has completed. Now read from ping, and write to pong.
        write_ping = false;
        read_addr = capture_buf1;
        write_addr = capture_buf2;
		gpio_put(25, 1); 
    } else {
        write_ping = true;
        read_addr = capture_buf2;
        write_addr = capture_buf1;
		gpio_put(25, 0); 
    }
	// Kick off the next transfer.
    dma_channel_set_write_addr(dma_chan1, write_addr, true);
	TRGGcounter=0;
	#else
	write_ping=true;
	#endif
}

static int core0_rx_val = 0;
void core0_interrupt_handler() {
    // Just record the latest entry
    while (multicore_fifo_rvalid())
        timebase = multicore_fifo_pop_blocking();
    multicore_fifo_clear_irq();
}

void core1_entry() {
	#ifdef VERSION_1_1
	uint8_t rangeASW[]={0x00,0x20,0x60,0x40,0x20,0x60,0x40}, rangeBSW[]={0x00,0x4,0x6,0x2,0x4,0x6,0x2};
	#else
	uint8_t rangeASW[]={0x00,0x40,0x60,0x20,0x40,0x60,0x20}, rangeBSW[]={0x00,0x80,0xC0,0x40,0x80,0xC0,0x40};
	#endif
	uint8_t aState,aLastState, timebase_old=18;
	int8_t timebase=18, encoder_step_1=0, encoder_step_2=0;
	uint16_t PCF8785out 	= 	0;
	uint32_t debounce=0;
	i2c_init(i2c0, 400 * 1000);  //400kHz
	gpio_set_function(20, GPIO_FUNC_I2C);  //SDA
	gpio_set_function(21, GPIO_FUNC_I2C);  //SCL
	gpio_pull_up(20);
    gpio_pull_up(21);
	uint8_t low[2]={0x00,0x00};
	i2c_write_blocking(i2c0, 0x21, low, 2, false);
	#ifdef CAT9555	
	uint8_t config[] = {
        0x06,  // Register pointer: Configuration Port 0
        0xFF,  // Port 0 = all input
		0xFF   // Port 1 = all input
    };
    i2c_write_blocking(i2c0, 0x20, config, 3, false);
	#else
	uint8_t high[2]={0xFF,0xFF};
	i2c_write_blocking(i2c0, 0x20, high, 2, false);
	#endif

	uint8_t configs[config_array_size];

	dia_chi = eeprom_wl_init(configs);

	MENU = configs[0];
	if(MENU < 0 || MENU > 6) MENU = 1;
	show_mode = configs[1];
	if(show_mode < 1 || show_mode > 3) show_mode = 1; //CH1+CH2=1;  CH1=2;  CH2=3;
	Stats_source = configs[2];
	if(Stats_source < 1 || Stats_source > 2) Stats_source = 1; //1=CH1; 2=CH2;
	trigger_source = configs[3];
	if(trigger_source < 1 || trigger_source > 4) trigger_source = 3; //CH1_UP=3; CH1_DWN=1; CH2_UP=4; CH2_DWN=2;
	timebase = configs[4];
	if(timebase < 0 || timebase > 23) timebase = 23;
	volbase1 = configs[5];
	if(volbase1 < 0 || volbase1 > 6) volbase1 = 3;// Vol base index channel 1: 0-6
	volbase2 = configs[6];
	if(volbase2 < 0 || volbase2 > 6) volbase2 = 3;// Vol base index channel 2: 0-6
	range_cursor = configs[7];
	if(range_cursor < 1 || range_cursor > 2) range_cursor = 1;//Enc_SW cursor: 1=CH1, 2=CH2
	CH1_Opto = configs[8];
	if((CH1_Opto!=CH1_AC)&&(CH1_Opto!=CH1_DC)) CH1_Opto = CH1_DC;
	CH2_Opto = configs[9];
	if((CH2_Opto!=CH2_AC)&&(CH2_Opto!=CH2_DC)) CH2_Opto = CH2_DC;
	Hold = configs[10];
	if(Hold < 0 || Hold > 1) Hold = 0;
	//MODE = configs[11];
	if(MODE < 1 || MODE > 2) MODE = 1;
	Acquisition = (bool)configs[12];

	load_calibration_data();
	for(int i=0; i<7; i++) {
		if(Z_offset1[i]>1824 || Z_offset1[i]<224) Z_offset1[i] = 1024;
		if(Z_offset2[i]>1824 || Z_offset2[i]<224) Z_offset2[i] = 1024;
		if(Vbase_fullscale1[i]<150) Vbase_fullscale1[i] = 250;
		if(Vbase_fullscale2[i]<150) Vbase_fullscale2[i] = 250;
	}



	bool timebase_change=false;
	while(true) {
		absolute_time_t now = get_absolute_time();
		uint16_t button = PCF8575_readButton16();
		process_buttons(button);
		//============================================================== ENCODER 1
		switch(encoder_step_1)
		{
			case 0: 
				if(!(button&ENCODER1_A)) encoder_step_1--;
				if(!(button&ENCODER1_B)) encoder_step_1++;
				break;
			case 1:
				if(!(button&ENCODER1_A)) encoder_step_1++;
				break;
			case -1:
				if(!(button&ENCODER1_B)) encoder_step_1--;
				break;
			case 2:
				if((button&0x0003)==0x0003) {timebase++;old_virIndex=virIndex;old_pix=tgpx+xCursor;}
				break;
			case -2:
				if((button&0x0003)==0x0003) {timebase--;old_virIndex=virIndex;old_pix=tgpx+xCursor;}
				break;
		}
		if((button&0x0003)==0x0003){
			encoder_step_1=0;
		}

		if(timebase_old!=timebase)
		{
			if(timebase<0) timebase=0;
			if(timebase>23) timebase=23;
			if(MODE==2 && timebase>18) timebase=18;
			while (multicore_fifo_wready())
    		multicore_fifo_push_blocking(timebase);  // Send something to Core0, this should fire the interrupt.
			//SET_FREQ_ADC(timebase_table[timebase]);
			config_id=100;
			timebase_change=true;
		}
		timebase_old = timebase;
		//======================================================================= ENCODER 2
		switch(encoder_step_2)
		{
			case 0: 
				if(!(button&ENCODER2_A)) encoder_step_2--;
				if(!(button&ENCODER2_B)) encoder_step_2++;
				break;
			case 1:
				if(!(button&ENCODER2_A)) encoder_step_2++;
				break;
			case -1:
				if(!(button&ENCODER2_B)) encoder_step_2--;
				break;
			case 2:
				if((button&0x000C)==0x000C) {
					if(Hold==0) {
						config_id=100;if(range_cursor==CH2)volbase2--; else volbase1--;
					}
					else xCursor+=5;
				}
				break;
			case -2:
				if((button&0x000C)==0x000C) {
					if(Hold==0) {
						config_id=100;if(range_cursor==CH2)volbase2++; else volbase1++;
					}
					else xCursor-=5;
				}
				break;
		}
		if((button&0x000C)==0x000C)
		{
			encoder_step_2=0;
		}
		if(volbase1<0) volbase1=0;if(volbase2<0) volbase2=0;
		if(volbase1>6) volbase1=6;if(volbase2>6) volbase2=6;
		//=======================================================================
		{
			#ifdef VERSION_1_1
			uint16_t relay = 0;
			if(volbase1>3) relay  = CH1_x10<<8;
			if(volbase2>3) relay |= CH2_x10<<8;
			PCF8785out = relay | rangeASW[volbase1] | (CH1_Opto|rangeBSW[volbase2]|CH2_Opto)<<8;
			uint8_t input[2]={PCF8785out&0xFF,PCF8785out>>8};
  			i2c_write_blocking(i2c0, 0x21, input, 2, true);
			#else
			PCF8785out = (rangeASW[volbase1]|CH1_Opto)   |   ((rangeBSW[volbase2]|CH2_Opto)<<8);
			if(volbase1>3) PCF8785out |= 0x1E;
			if(volbase2>3) PCF8785out |= (0x3C<<8);
			uint8_t input[2]={PCF8785out&0xFF,PCF8785out>>8};
  			i2c_write_blocking(i2c0, 0x21, input, 2, true);
			#endif
		}
		
		if(config_id > 0)
		{
			if(config_id == 100) {event = 50000; config_id = 99;}
			if (event>0) {
				event--;
				if(event==49900) SET_FREQ_ADC(timebase_table[timebase]);
			}
			else {
				uint8_t _id;
				if     (configs[ 0]!=MENU)               {_id=0;  configs[ 0]=MENU;}
				else if(configs[ 1]!=show_mode)          {_id=1;  configs[ 1]=show_mode;}
				else if(configs[ 2]!=Stats_source)       {_id=2;  configs[ 2]=Stats_source;}
				else if(configs[ 3]!=trigger_source)     {_id=3;  configs[ 3]=trigger_source;}
				else if(configs[ 4]!=timebase)           {_id=4;  configs[ 4]=timebase;}
				else if(configs[ 5]!=volbase1)           {_id=5;  configs[ 5]=volbase1;}
				else if(configs[ 6]!=volbase2)           {_id=6;  configs[ 6]=volbase2;}
				else if(configs[ 7]!=range_cursor)       {_id=7;  configs[ 7]=range_cursor;}
				else if(configs[ 8]!=CH1_Opto)           {_id=8;  configs[ 8]=CH1_Opto;}
				else if(configs[ 9]!=CH2_Opto)           {_id=9;  configs[ 9]=CH2_Opto;}
				else if(configs[10]!=Hold)               {_id=10; configs[10]=Hold;}
				else if(configs[11]!=MODE)               {_id=11; configs[11]=MODE;}
				else if((bool)configs[12]!=Acquisition)  {_id=12; configs[12]=(uint8_t)Acquisition;}
				else config_id = 0;
				if(config_id>0) dia_chi = eeprom_write_new_block(_id, configs[_id]);
			}
		}
		if(Save_calib) { save_calibration_data(); Save_calib = false; }
	}
}



int main() {
    //Overclock Powerrrr!
    set_sys_clock_khz(250000, true);
    stdio_init_all();
	multicore_launch_core1(core1_entry);
	multicore_fifo_clear_irq();
	#ifdef RP2350
	irq_set_exclusive_handler(SIO_FIFO_IRQ_NUM(0), core0_interrupt_handler);
    irq_set_enabled(SIO_FIFO_IRQ_NUM(0), true);
	#else
	irq_set_exclusive_handler(SIO_IRQ_PROC0, core0_interrupt_handler);
    irq_set_enabled(SIO_IRQ_PROC0, true);
	#endif
    
	systick_hw->csr = 0; 	    //Disable 
	systick_hw->rvr = 249999UL; //Standard System clock (125Mhz)/ (rvr value + 1) = 1ms 
	systick_hw->cvr = 0;        //clear the count to force initial reload
    systick_hw->csr = 0x7;      //Enable Systic, Enable Exceptions	

    uint freq = 1000000;
    float clockDiv = (float)clock_get_hz(clk_sys) / (float)(freq * 2);
    offset = pio_add_program(pio, &adc_capture_program);
	offset10 = pio_add_program(pio, &adc_capture_x10_program);
	offset100 = pio_add_program(pio, &adc_capture_x100_program);
	offset1000 = pio_add_program(pio, &adc_capture_x1000_program);
    adc_capture_program_init(pio, sm, offset, 1, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);

    dma_chan1 = dma_claim_unused_channel(true);
    dma_channel_config dma_config1 = dma_channel_get_default_config(dma_chan1);
    channel_config_set_read_increment(&dma_config1, false);
    channel_config_set_write_increment(&dma_config1, true);
	channel_config_set_transfer_data_size(&dma_config1, DMA_SIZE_16);
    channel_config_set_dreq(&dma_config1, pio_get_dreq(pio, sm, false));
	//channel_config_set_chain_to(&dma_config1, dma_chan2); // ping-pong
    dma_channel_configure(dma_chan1, &dma_config1,
        &adc_buf,        // Destination pointer
        &pio0->rxf[sm],       // Source pointer
        BUFFER_SIZE,      // Number of transfers
        false                 // Start immediately
    );

	irq_set_exclusive_handler(DMA_IRQ_0, dma_handler);
	dma_channel_set_irq0_enabled(dma_chan1, true);
	irq_set_enabled(DMA_IRQ_0, true);
    dma_handler();

    pio_sm_set_enabled(pio, sm, false);
    pio_sm_clear_fifos(pio, sm);
    pio_sm_restart(pio, sm);
	pio_sm_set_enabled(pio, sm, true);

	gpio_init(25);
    gpio_set_dir(25, GPIO_OUT);
	gpio_put(25, 1); 


	
	#ifdef VERSION_1_1
	adc_init();
    adc_gpio_init(28);
    adc_select_input(2); //2 = pin 28;
    #endif
	
    calib_mode = 5;
    LCD_Init();
	LCD_FillScreen(BGR);
    LCD_WriteString(104, 102, "PiSCOPE", Font_16x26, WHITE, BGR);
	LCD_WriteString(83, 135, "Sampling Rate 125MSa/s", Font_7x10, WHITE, BGR);
	sleep_ms(2000);
    LCD_WriteString(80, 135, "     Firmware 1.1.2     ", Font_7x10, WHITE, BGR);

	uint8_t eer = 0;
	while (show_mode==100)
	{
		LCD_WriteString(79, 135, "      Load memory      ", Font_7x10, WHITE, BGR);
		sleep_ms(300);
		if (dia_chi > 0) break;
		LCD_WriteString(79, 135, "      Load memory.     ", Font_7x10, WHITE, BGR);
		sleep_ms(300);
		if (dia_chi > 0) break;
		LCD_WriteString(79, 135, "      Load memory..    ", Font_7x10, WHITE, BGR);
		sleep_ms(300);
		if (dia_chi > 0) break;
		LCD_WriteString(79, 135, "      Load memory...   ", Font_7x10, WHITE, BGR);
		sleep_ms(300);
		if (dia_chi > 0) break;

		if (++eer > 5) {
			LCD_WriteString(79, 135, "     EEprom error!     ", Font_7x10, WHITE, BGR);
			show_mode = 1;
			sleep_ms(1000);
			break;
		}
	}
	
	sleep_ms(2000);
	critical_section_init(&my_lock);
	#ifdef VERSION_1_1
	for(int i=0; i<20; i++) Bvol += adc_read()*6.776f/(1<<12);
	#endif
	
	LCD_WriteString(2, 2, "BVA", Font_7x10, LOGO, BGR);LCD_WriteString(28, 2, "Run", Font_7x10, WHITE, BGR);

	old_tgpx=0;

	if(show_mode==2) {
		range_cursor = CH1;position_wave = 0;
		Stats_source = 1;
		if      (trigger_source==2) {trigger_source=1;trigger_pos_y = trigger_pos_y*VolPerDIV[volbase2]/VolPerDIV[volbase1];}   
		else if (trigger_source==4) {trigger_source=3;trigger_pos_y = trigger_pos_y*VolPerDIV[volbase2]/VolPerDIV[volbase1];}
	}
	if(show_mode==3) {
		range_cursor = CH2;position_wave = 1;
		Stats_source = 2;
		if(trigger_source == 1 || trigger_source == 3) {
			if(trigger_source == 1) trigger_source = 2;
			else trigger_source = 4;
			trigger_pos_y = trigger_pos_y * VolPerDIV[volbase1] / VolPerDIV[volbase2];
		}
	}

	if(calib_mode==5) calib_mode=0;
	uint32_t time_draw_stats;
	if(MODE==1) clear=false; else clear=true;
	bool polling=false;
	bool first=false;
	gpio_put(25, 0); 
	MARSK_SCREEN();
	for(int i=0; i<402; i++)
	{LCD_Buffer[i]=0;}
	SEARCH_TRIGGER_POINT(over_sample);
	trigger_pos_drawing=tgpx;  //150
	trigger_pos_t = GRID_WIDTH/2 + (tgpx+xCursor);
	if (trigger_pos_t<0) trigger_pos_t=0;
	if (trigger_pos_t>GRID_WIDTH) trigger_pos_t=GRID_WIDTH;
	trigger_pos_t -=3; // trigger pos Icon has 6pixel, 3 is a haft.
	config_id=100;
	fft_init();//FFT
	for(int i=0; i<=GRID_WIDTH; i++) {
		memset(LCD_Buffer, 0x00, sizeof(LCD_Buffer)); // Clear the entire buffer with zeros
		//Draw grid:
		GRID_MARK(i);
		LCD_FillBuffer(i, LCD_Buffer);
	}

    while (true) {
	    int start_tick = systick.u32_tick_count;

		critical_section_enter_blocking(&my_lock);
		if(MODE==1) OSC=true; else OSC=false;
		critical_section_exit(&my_lock);

		if(clear!=OSC) {
			config_id=100;
			clear=OSC;
			LCD_FillRectangle(5, 217, 314, 22, BGR);
			if(!OSC) {
				LCD_FillRectangle(5, 217, 314, 22, BGR);
			} else {
				if(show_mode==2) {
					range_cursor = CH1;position_wave = 0;
					Stats_source = 1;
					if      (trigger_source==2) {trigger_source=1;trigger_pos_y = trigger_pos_y*VolPerDIV[volbase2]/VolPerDIV[volbase1];}   
					else if (trigger_source==4) {trigger_source=3;trigger_pos_y = trigger_pos_y*VolPerDIV[volbase2]/VolPerDIV[volbase1];}
				}
				if(show_mode==3) {
					range_cursor = CH2;position_wave = 1;
					Stats_source = 2;
					if(trigger_source == 1 || trigger_source == 3) {
						if(trigger_source == 1) trigger_source = 2;
						else trigger_source = 4;
						trigger_pos_y = trigger_pos_y * VolPerDIV[volbase1] / VolPerDIV[volbase2];
					}
				}
			}
			vRange_change=100;
		}
		if(write_ping) {
			gpio_put(25, 1); 
			if(!Hold) {
				if(timebase_old!=timebase) {
					timebase_old=timebase;
				} else {
					for(int i=0; i<CAPTURE_N_SAMPLES ; i++) {
						uint8_t b = adc_buf[i]&0xFF;
						ch1Capture[i] = reverse_lookup[b];
						ch2Capture[i] = reverse_lut[adc_buf[i] >> 8];
					}
					smp_Range = timebase;first=true;
					if(smp_Range>18) smp_Range=18;
				}
				dma_channel_set_write_addr(dma_chan1, adc_buf, true);
				gpio_put(25, 0);
				write_ping=false;
			}
		}
		if(OSC) {
			bool data_valid = false;
			for (int i = 0; i < 4096; i++) {
				if (ch1Capture[i] != 0) {
					data_valid = true;
					break;
				}
			}
			if (data_valid&&first) {
				DRAW_WAVE(0,Over_Samples[timebase]);
			}
			WAVE_INFO_CALCULATOR(Over_Samples[timebase]);
			MARSK_SCREEN();
			DRAW_WAVE_POS_ICON();
			DRAW_TRIGG_PosXY();
			int stick = systick.u32_tick_count;
			if(time_draw_stats+200<stick) {
				Stats.Vmaxf /= Stats.count;
				Stats.Vminf /= Stats.count;
				Stats.freq  /= Stats.count;
				Stats.duty  /= Stats.count;
				Stats.count = 0;
				DRAW_STATS_WAVE();
				time_draw_stats = stick;
				Stats.Vmaxf = 0;
				Stats.Vminf = 0;
				Stats.freq  = 0;
				Stats.duty  = 0;
				uint32_t frame_period =  stick - start_tick;
				int FPS = (int)(1000/(float)frame_period);
				char bufnum[7];
				sprintf (bufnum, "%d", FPS);
				LCD_WriteNumber(295,229,FPS/10, MAGENTA,BGR);
				LCD_WriteNumber(295+7,229,FPS%10, MAGENTA,BGR);
			}
		} else {
			bool data_valid = false;
			for (int i = 0; i < N; i++) {
				if (ch1Capture[i] != 0) {
					data_valid = true;
					break;
				}
			}
			if (data_valid&&first) {
				DRAW_FFT(); // gọi FFT khi dữ liệu đã được điền
			}
			MARSK_SCREEN();
			DRAW_WAVE_POS_ICON();
			DRAW_TRIGG_PosXY();
			int stick = systick.u32_tick_count;
			if(time_draw_stats+200<stick) {
				FFT.tdh  /= FFT.count;
				FFT.sfdr /= FFT.count;
				FFT.freq /= FFT.count;
				FFT.count = 0;
				DRAW_FFT_info();
				time_draw_stats = stick;
				FFT.tdh  = 0;
				FFT.sfdr = 0;
				FFT.freq = 0;
				uint32_t frame_period =  stick - start_tick;
				int FPS = (int)(1000/(float)frame_period);
				char bufnum[7];
				sprintf (bufnum, "%d", FPS);
				LCD_WriteNumber(295,229,FPS/10, MAGENTA,BGR);
				LCD_WriteNumber(295+7,229,FPS%10, MAGENTA,BGR);
			}
		}
		#ifdef VERSION_1_1
		if(cnt<10) cnt++;
		else{
			Bvol = Bvol - Bvol/20;
			Bvol += adc_read()*6.776f/(1<<12);
			cnt=0;
		}
		#endif
    }
}







void GRID_MARK(uint16_t i) {
	if(i%25==0) //Ngang;   20 is the first H grid
	{
		uint8_t hi = TRACE >> 8;
    	uint8_t lo = TRACE & 0xFF;

		// Gán theo bước 5, bỏ qua y == 100 (xử lý riêng)
		for (int y = 0; y <= 200; y += 5)
		{
			if (y == 100) continue;
			LCD_Buffer[2 * y]     = hi;
			LCD_Buffer[2 * y + 1] = lo;
		}

		// Xử lý riêng phần giữa
		LCD_Buffer[2 * 99] = hi;     LCD_Buffer[2 * 99 + 1] = lo;
		LCD_Buffer[2 * 100] = hi;    LCD_Buffer[2 * 100 + 1] = lo;
		LCD_Buffer[2 * 101] = hi;    LCD_Buffer[2 * 101 + 1] = lo;

		// Xử lý viền đầu/cuối
		LCD_Buffer[2 * 1] = hi;      LCD_Buffer[2 * 1 + 1] = lo;
		LCD_Buffer[2 * 2] = hi;      LCD_Buffer[2 * 2 + 1] = lo;
		LCD_Buffer[2 * 198] = hi;    LCD_Buffer[2 * 198 + 1] = lo;
		LCD_Buffer[2 * 199] = hi;    LCD_Buffer[2 * 199 + 1] = lo;
	}
	else     //DOC
	{
		//Clear LCD buffer
		//for (uint16_t i = 0; i < 2*201; i++)
		//{
		//	LCD_Buffer[i] = 0x00;
		//}
		uint8_t hi = TRACE >> 8;
		uint8_t lo = TRACE & 0xFF;

		if (i == 1 || i == 2 || i == 149 || i == 151 || i == GRID_WIDTH - 2 || i == GRID_WIDTH - 1)
		{
			for (int y = 0; y <= 200; y += 5)
			{
				LCD_Buffer[2 * y]     = hi;
				LCD_Buffer[2 * y + 1] = lo;
			}
		}

		if (i % 5 == 0)
		{
			for (int y = 0; y <= 200; y += 25)
			{
				LCD_Buffer[2 * y]     = hi;
				LCD_Buffer[2 * y + 1] = lo;

				if (y == 100)
				{
					LCD_Buffer[2 * (y - 1)]     = hi;
					LCD_Buffer[2 * (y - 1) + 1] = lo;
					LCD_Buffer[2 * (y + 1)]     = hi;
					LCD_Buffer[2 * (y + 1) + 1] = lo;
				}
			}

			// Viền trên dưới
			LCD_Buffer[2 * 1]     = hi; LCD_Buffer[2 * 1 + 1]     = lo;
			LCD_Buffer[2 * 2]     = hi; LCD_Buffer[2 * 2 + 1]     = lo;
			LCD_Buffer[2 * 198]   = hi; LCD_Buffer[2 * 198 + 1]   = lo;
			LCD_Buffer[2 * 199]   = hi; LCD_Buffer[2 * 199 + 1]   = lo;
		}
	}
	if(i==0 || i==GRID_WIDTH) //Doc;   20 is the first H grid
	{
		for(int y=0; y<=200; y++)
		{
			LCD_Buffer[2*y] = TRACE>>8; LCD_Buffer[2*y+1] = TRACE&0xFF;
		}
	}
	else
	{
		LCD_Buffer[0] = TRACE>>8; LCD_Buffer[0+1] = TRACE&0xFF;
		LCD_Buffer[2*200] = TRACE>>8; LCD_Buffer[2*200+1] = TRACE&0xFF;
	}

	//Doc:
	if(i==trigger_pos_t || i==trigger_pos_t+6)
	{
		LCD_Buffer[4] = YELLOW>>8;
		LCD_Buffer[5] = YELLOW&0xFF;
	}
	if(i==trigger_pos_t+1 || i==trigger_pos_t+5)
	{
		LCD_Buffer[4] = YELLOW>>8;
		LCD_Buffer[5] = YELLOW&0xFF;
		LCD_Buffer[6] = YELLOW>>8;
		LCD_Buffer[7] = YELLOW&0xFF;
	}
	if(i==trigger_pos_t+2 || i==trigger_pos_t+4)
	{
		LCD_Buffer[4] = YELLOW>>8;
		LCD_Buffer[5] = YELLOW&0xFF;
		LCD_Buffer[6] = YELLOW>>8;
		LCD_Buffer[7] = YELLOW&0xFF;
		LCD_Buffer[8] = YELLOW>>8;
		LCD_Buffer[9] = YELLOW&0xFF;
	}
	if(i==trigger_pos_t+3)
	{
		LCD_Buffer[2] = YELLOW>>8;
		LCD_Buffer[3] = YELLOW&0xFF;
		LCD_Buffer[4] = YELLOW>>8;
		LCD_Buffer[5] = YELLOW&0xFF;
		LCD_Buffer[6] = YELLOW>>8;
		LCD_Buffer[7] = YELLOW&0xFF;
		LCD_Buffer[8] = YELLOW>>8;
		LCD_Buffer[9] = YELLOW&0xFF;
		LCD_Buffer[10] = YELLOW>>8;
		LCD_Buffer[11] = YELLOW&0xFF;
	}
}

void DRAW_STATS_WAVE(void) {//slow down 25fps to 23fps
	//Vpp:
	int vpp=0,max=0,min=0;
	float vmax,vmin;
	float zeroV, gain;
	Stats_color = (Stats_source == 1) ? YELLOW : CYAN;

	if (Stats_source == 1) {
		zeroV = Z_offset1[volbase1]/8.0f;
		gain  = Vbase_fullscale1[volbase1];
	} else {
		zeroV = Z_offset2[volbase2]/8.0f;
		gain  = Vbase_fullscale2[volbase2];
	}

	float vPerDiv = VolPerDIV[(Stats_source == 1) ? volbase1 : volbase2];

	vmax = (zeroV - Stats.Vminf) * 8 * vPerDiv * gain / 256.0 / 200;
	vmin = (zeroV - Stats.Vmaxf) * 8 * vPerDiv * gain / 256.0 / 200;

	printFloat(140, 217, vmax, 5, 1, Font_7x10, WHITE, BGR);
	LCD_WriteString(178,217, "V", Font_7x10, WHITE, BGR);
	
	printFloat(140, 229, vmin, 5, 1, Font_7x10, WHITE, BGR);
	LCD_WriteString(178,229, "V", Font_7x10, WHITE, BGR);

	//duty:
	//Stats.duty = 500;
	// Giới hạn duty cycle và đảo chiều (nghịch đảo %)
	if (Stats.duty > 1000) Stats.duty = 1000;
	Stats.duty = 1000 - Stats.duty;

	// Hiển thị duty cycle, định dạng xx.x%
	LCD_WriteString(247, 229, "  . ", Font_7x10, WHITE, BGR);  // Xóa số cũ
	if (Stats.duty >= 100) {
		LCD_WriteNumber(247, 229, Stats.duty / 100, WHITE, BGR);       // Hàng trăm
	}
	LCD_WriteNumber(254, 229, (Stats.duty / 10) % 10, WHITE, BGR);     // Hàng chục
	LCD_WriteNumber(264, 229, Stats.duty % 10, WHITE, BGR);            // Hàng đơn vị
	LCD_WriteString(271, 229, "%", Font_7x10, WHITE, BGR);

	// Hiển thị tần số
	float frq = Stats.freq;
	const char* unit = "Hz";
	if (frq <= 0) {
		LCD_WriteString(240, 217, " ?Hz      ", Font_7x10, WHITE, BGR);
	} else {
		if (frq < 1000) {
			unit = "Hz ";
		} else if (frq < 1000000) {
			frq /= 1000.0;
			unit = "kHz";
		} else {
			frq /= 1000000.0;
			unit = "MHz";
		}
		printFloat(240, 217, frq, 7, 1, Font_7x10, WHITE, BGR);
		LCD_WriteString(289, 217, unit, Font_7x10, WHITE, BGR);
	}
}

void WAVE_INFO_CALCULATOR(uint8_t over_sample) {

	uint16_t N_Sample_calc = 5 * GRID_WIDTH * over_sample;
    uint16_t half_samples = N_Sample_calc / 2;
	uint16_t buffer_limit = CAPTURE_N_SAMPLES  - N_Sample_calc - 200;

	uint16_t start_point_calc = (Index < half_samples) ? 200 :
					(Index > buffer_limit) ? buffer_limit : Index;
	uint16_t end_point_calc = start_point_calc + N_Sample_calc;

	uint8_t* buffer = (Stats_source == 1) ? ch1Capture : ch2Capture;
	uint16_t dataMin = 255, dataMax = 0;

	for (uint32_t o = start_point_calc; o < end_point_calc; o++) {
		uint8_t d = movingAvg(buffer, o, CAPTURE_N_SAMPLES ); // <-- có thể thay bằng filter đơn giản hơn
		if (d < dataMin) dataMin = d;
		if (d > dataMax) dataMax = d;
	}

	Stats.Vmaxf += dataMax;
	Stats.Vminf += dataMin;

	int swingCenter = (dataMin + dataMax) / 2;
	int noiseThreshold = (dataMax - dataMin) / 10;

	float p0 = 0, lastPosiEdge = 0, periods[MAX_CYCLES], widths[MAX_CYCLES];
	int periodCount = 0, widthCount = 0;
	uint8_t a0Detected = 0, posiSearch = 1;

	int y1 = movingAvg(buffer, start_point_calc, CAPTURE_N_SAMPLES );
	for (int i = start_point_calc; i < end_point_calc - over_sample; i += over_sample) {
		int y2 = movingAvg(buffer, i + over_sample, CAPTURE_N_SAMPLES );

		if (posiSearch && y1 <= swingCenter && y2 > swingCenter) {
			float pFine = (float)(swingCenter - y1) / ((swingCenter - y1) + (y2 - swingCenter));
			float edge = i + pFine;
			if (!a0Detected) { a0Detected = 1; p0 = edge; }
			else if (periodCount < MAX_CYCLES) { periods[periodCount++] = edge - p0; p0 = edge; }
			lastPosiEdge = edge;
			posiSearch = 0;
		} else if (!posiSearch && y1 >= swingCenter && y2 < swingCenter) {
			float pFine = (float)(y1 - swingCenter) / ((y1 - swingCenter) + (swingCenter - y2));
			float fall = i + pFine;
			if (widthCount < MAX_CYCLES) widths[widthCount++] = fall - lastPosiEdge;
			posiSearch = 1;
		}

		y1 = y2; // tránh gọi movingAvg 2 lần
	}

	// Calculate trimmed mean
	float sump = 0;
	float sumd = 0;
	int trimp;
	int trimd;
	if (periodCount >= 2) {
		qsort(periods, periodCount, sizeof(float), cmp_float);
		trimp = periodCount / 10;
		//float sum = 0;
		for (int i = trimp; i < periodCount - trimp; ++i) sump += periods[i];
		Stats.freq += 25.0 * Over_Samples[smp_Range] / (timebaseValue[smp_Range] * (sump / (periodCount - 2 * trimp))) + 0.5;
	}

	if (widthCount >= 1) { //Chưa chính xác
		qsort(widths, widthCount, sizeof(float), cmp_float);
		trimd = widthCount / 10;
		//float sum = 0;
		for (int i = trimd; i < widthCount - trimd; ++i) sumd += widths[i];
		Stats.duty += 1000.0 * (sumd / (widthCount - 2 * trimd)) / (sump / (periodCount - 2 * trimp));
	}
	Stats.count++;
}

void MARSK_SCREEN(void) {
	LCD_WriteString(2, 2, "BVA", Font_7x10, GREEN, BGR);


	if (Hold) LCD_WriteString(28, 2, "Hold", Font_7x10, BLACK, RED); else LCD_WriteString(28, 2, "Run ", Font_7x10, WHITE, BGR);
	LCD_WriteString(65, 2, ":", Font_7x10, WHITE, BGR);
	LCD_WriteString(60, 2, "M", Font_7x10, WHITE, BGR);

	LCD_WriteString(72, 2, TIMEBASE_STRINGS[timebase], Font_7x10, WHITE, BGR);

	#ifdef VERSION_1_1
	uint16_t bx = 300, by = 1;
	float pin = (Bvol/20-3.3)*10/0.9;
	if(pin<0) pin=0; if(pin>10) pin=10;
	LCD_FillRectangle(bx+1, by, 12, 1, WHITE);
	LCD_FillRectangle(bx, by, 1, 9, WHITE);
	LCD_FillRectangle(bx+2, by+2, (int)pin, 5, WHITE);
	LCD_FillRectangle(bx+2+(int)pin, by+2, 10-(int)pin, 5, BGR);
	LCD_FillRectangle(bx+13, by, 1, 9, WHITE);
	LCD_FillRectangle(bx+14, by+3, 1, 3, WHITE);
	LCD_FillRectangle(bx+1, by+8, 12, 1, WHITE);
	#endif

	if(OSC) {
		if (MENU==3)
		{
			if(position_wave) LCD_WriteString(143, 2, " CH2 ", Font_7x10, YELLOW, BGR);
			else LCD_WriteString(143, 2, " CH1 ", Font_7x10, YELLOW, BGR);
		}
		else if (MENU==4)
		{
			LCD_WriteString(139, 2, " SHOW ", Font_7x10, YELLOW, BGR);
		}
		else if (MENU==5)
		{
			LCD_WriteString(143, 2, "TRIGG", Font_7x10, YELLOW, BGR);
		}
		else if (MENU==6)
		{
			LCD_WriteString(143, 2, "T-Pos", Font_7x10, YELLOW, BGR);
		}

		uint8_t X_pos=28;
		if(vRange_change != volbase1+volbase2)
		{
			uint16_t LABEL_color = BGR, text_color = BGR;
			
			if(show_mode==3) {LABEL_color = BGR; text_color = BGR;LCD_WriteString(5,217, "CH1", Font_7x10, BGR, LABEL_color);}
			else {LABEL_color = YELLOW;text_color = WHITE;LCD_WriteString(5,217, "CH1", Font_7x10, BLACK, LABEL_color);}

			if(range_cursor==CH1) LCD_WriteString(81,217, "<<<", Font_7x10, text_color, BGR); else LCD_WriteString(81,217, "<<<", Font_7x10, BGR, BGR);
			if(CH1_Opto==CH1_AC) LCD_WriteString(60,217, "AC ", Font_7x10, text_color, BGR);
			else LCD_WriteString(60,217, "DC ", Font_7x10, text_color, BGR);
			LCD_WriteString(X_pos, 217, VOLTAGE_STRINGS[volbase1], Font_7x10, text_color, BGR); // Voltage/Div
			
			if(show_mode==2) {LABEL_color = BGR; text_color = BGR;LCD_WriteString(5,229, "CH2", Font_7x10, BGR, LABEL_color);}
			else {LABEL_color = CYAN;text_color = WHITE;LCD_WriteString(5,229, "CH2", Font_7x10, BLACK, LABEL_color);}
			
			if(range_cursor==CH2) LCD_WriteString(81,229, "<<<", Font_7x10, text_color, BGR); else LCD_WriteString(81,229, "<<<", Font_7x10, BGR, BGR);
			if(CH2_Opto==CH2_AC) LCD_WriteString(60,229, "AC ", Font_7x10, text_color, BGR);
			else LCD_WriteString(60,229, "DC ", Font_7x10, text_color, BGR);
			LCD_WriteString(X_pos, 229, VOLTAGE_STRINGS[volbase2], Font_7x10, text_color, BGR); // Voltage/Div
			
			vRange_change = volbase1+volbase2;
		}
		if(Stats_source==CH2) Stats_color = CYAN; else Stats_color = YELLOW;
		LCD_WriteString(110,217, "Vmax", Font_7x10, BLACK, Stats_color);//LCD_WriteString(140,217, "3.25V", Font_7x10, WHITE, BGR);
		LCD_WriteString(110,229, "Vmin", Font_7x10, BLACK, Stats_color);//LCD_WriteString(140,229, "582mV", Font_7x10, WHITE, BGR);
		LCD_WriteString(210,217, "Freq", Font_7x10, BLACK, Stats_color);//LCD_WriteString(240,217, "1.00kHz", Font_7x10, WHITE, BGR);
		LCD_WriteString(210,229, "Duty", Font_7x10, BLACK, Stats_color);//LCD_WriteString(240,229, "50%", Font_7x10, WHITE, BGR);
	} else {
		if(FFT_CH==1) LCD_WriteString(143, 2, " CH1 ", Font_7x10, YELLOW, BGR);
		else          LCD_WriteString(143, 2, " CH2 ", Font_7x10, YELLOW, BGR);
		
		uint8_t X_pos=28;
		uint16_t LABEL_color = BGR, text_color = BGR;
		if(FFT_CH==1) {
			LABEL_color = YELLOW;text_color = WHITE;
			LCD_WriteString(5,217, "CH1", Font_7x10, BLACK, LABEL_color);
			LCD_WriteString(X_pos, 217, VOLTAGE_STRINGS[volbase1], Font_7x10, text_color, BGR); // Voltage/Div
			if(CH1_Opto==CH1_AC) LCD_WriteString(60,217, "AC ", Font_7x10, text_color, BGR);
			else                 LCD_WriteString(60,217, "DC ", Font_7x10, text_color, BGR);
		}
		else if(FFT_CH==2) {
			LABEL_color = CYAN;text_color = WHITE;
			LCD_WriteString(5,217, "CH2", Font_7x10, BLACK, LABEL_color);
			LCD_WriteString(X_pos, 217, VOLTAGE_STRINGS[volbase2], Font_7x10, text_color, BGR); // Voltage/Div
			if(CH2_Opto==CH2_AC) LCD_WriteString(60,217, "AC ", Font_7x10, text_color, BGR);
			else                 LCD_WriteString(60,217, "DC ", Font_7x10, text_color, BGR);
		}
		
		LCD_WriteString(235, 217, FFT_WINDOW_STRINGS[window_type], Font_7x10, text_color, BGR);
		LCD_WriteString(10,229, "THD:", Font_7x10, text_color, BGR);
		LCD_WriteString(104,229, "SFDR:", Font_7x10, text_color, BGR);
		LCD_WriteString(85, 217, FFT_TIMEBASE_STRINGS[timebase], Font_7x10, text_color, BGR);
		vRange_change = volbase1+volbase2;
	}
	float flt;//Bvol
	#ifdef VERSION_1_1
	if (trigger_source%2==1)
	{
		flt=tgvol1;
		Stats_color = YELLOW;
		printFloat(250, 2, flt, 5, 1, Font_7x10, Stats_color, BGR); //260
		LCD_WriteString(210,2, "CH1", Font_7x10, Stats_color, BGR); //220
		LCD_WriteString(285,2, "V", Font_7x10, Stats_color, BGR); //295
	}
	else
	{
		flt=tgvol2;
		Stats_color = CYAN;
		printFloat(250, 2, flt, 5, 1, Font_7x10, Stats_color, BGR);
		LCD_WriteString(210,2, "CH2", Font_7x10, Stats_color, BGR);
		LCD_WriteString(285,2, "V", Font_7x10, Stats_color, BGR);
	}
	#else
	if (trigger_source%2==1) {
		flt=tgvol1;
		Stats_color = YELLOW;
		printFloat(260, 2, flt, 5, 1, Font_7x10, Stats_color, BGR);
		LCD_WriteString(220,2, "CH1", Font_7x10, Stats_color, BGR);
		LCD_WriteString(295,2, "V", Font_7x10, Stats_color, BGR);
	} else {
		flt=tgvol2;
		Stats_color = CYAN;
		printFloat(260, 2, flt, 5, 1, Font_7x10, Stats_color, BGR);
		LCD_WriteString(220,2, "CH2", Font_7x10, Stats_color, BGR);
		LCD_WriteString(295,2, "V", Font_7x10, Stats_color, BGR);
	}
	#endif
	//LCD_WriteNumber(2, 150, IDE, WHITE, BGR);
	DRAW_TRIGGER_ICON();
}

void DRAW_WAVE(uint16_t start_index, uint8_t over_sample) {
	if(!Hold) SEARCH_TRIGGER_POINT(over_sample);
	yCursorsSnap[A1] = yCursors[A1]; // set y in the middle
	yCursorsSnap[A2] = yCursors[A2]; // set y in the middle

	if(calib_mode==1) {
		if(show_mode==2) {
			int interger = Z_offset1[volbase1];
			Numtochar(interger,1,4,zcalib);
			interger = Vbase_fullscale1[volbase1];
			Numtochar(interger,1,3,vcalib);
		}
		if(show_mode==3) {
			int interger = Z_offset2[volbase2];
			Numtochar(interger,1,4,zcalib);
			interger = Vbase_fullscale2[volbase2];
			Numtochar(interger,1,3,vcalib);
		}
	}

	if      (show_mode==1) {wavesSnap[A1]=1; wavesSnap[A2]=1;}
	else if (show_mode==2) {wavesSnap[A1]=1; wavesSnap[A2]=0;}
	else                   {wavesSnap[A1]=0; wavesSnap[A2]=1;}
	
	trigger_pos_drawing=tgpx;  //150
	trigger_pos_t = GRID_WIDTH/2 + (tgpx+xCursor);
	if (trigger_pos_t<0) trigger_pos_t=0;
	if (trigger_pos_t>GRID_WIDTH) trigger_pos_t=GRID_WIDTH;
	trigger_pos_t -=3; // trigger pos Icon has 6pixel, 3 is a haft.

	val1 = 0;   val2 = 0;
	peakA1 = 0; peakA2 = 255;
	peakB1 = 0; peakB2 = 255;
	uint8_t lcd_inc=1, smp_inc=Over_Samples[timebase];
	scale = PX_SCALE[timebase]*Over_Samples[smp_Range]/PX_SCALE[smp_Range]; //số lượng mẫu ADC trên mỗi pixel theo chiều ngang.
	//scale = 20; 10; 8; 5; 4; 2,5; 2; 1; 0,8; 0,5; 0,4; 0,25; ...
	float ch1_scale_factor = Z_offset1[volbase1] / 8.0f - 128.0f / Vbase_fullscale1[volbase1];
	float ch2_scale_factor = Z_offset2[volbase2] / 8.0f - 128.0f / Vbase_fullscale2[volbase2];
	if(scale>=1) {
		virIndex = old_virIndex - (tgpx+xCursor-old_pix)*scale;
		if(Hold) {
			double temp = GRID_WIDTH/2 - virIndex/scale;
			if(temp>32767) temp=32767; else if(temp<-32768) temp=-32768;
			trigger_pos_t = temp;//GRID_WIDTH/2 - virIndex/scale;
			if (trigger_pos_t<0) trigger_pos_t=0;
			if (trigger_pos_t>GRID_WIDTH) trigger_pos_t=GRID_WIDTH;
			trigger_pos_t -=3; // trigger pos Icon has 6pixel, 3 is a haft.
		}
		double j;  //Start piont ADC to draw
		j = (double)Index + virIndex - GRID_WIDTH/2*scale;
		
		for(int i=0; i<=GRID_WIDTH; i++)
		{
			/*Clear LCD buffer*/
			memset(LCD_Buffer, 0x00, sizeof(LCD_Buffer)); // Clear the entire buffer with zeros
			if(peakA1<peakA2) {
				uint8_t tmp = peakA1;
				peakA1 = peakA2; peakA2 = tmp;
			}
			if(peakB1<peakB2) {
				uint8_t tmp = peakB1;
				peakB1 = peakB2; peakB2 = tmp;
			}
			
			double t1 = (j+i*scale)/1,
				   t2 = t1+(scale+0.5)/1;
			int    p1 = (int)t1,
				   p2 = (int)t2;

			if(p1>20 && p2<dynamic_size) {
				if (trigger_source%2==1) {
					if(wavesSnap[A2]) {
						if(Acquisition) {
							uint32_t sum = 0;
							for(int pos = p1; pos < p2; pos++) {
								sum += ch2Capture[pos];
							}
							float avg_float = (float)sum / (p2 - p1);
							if(avg_float < peakB1) peakB1 = avg_float;
							if(avg_float > peakB2) peakB2 = avg_float;
						} else {
							for(int pos=p1; pos<p2; pos++) {
								if(ch2Capture[pos]<peakB1) peakB1 = ch2Capture[pos];
								if(ch2Capture[pos]>peakB2) peakB2 = ch2Capture[pos];
							}
						}
						val1 = GRID_HEIGHT + ((int16_t)((peakB1 - ch2_scale_factor) * Vbase_fullscale2[volbase2]) >> 8) - yCursorsSnap[A2];
						val2 = GRID_HEIGHT + ((int16_t)((peakB2 - ch2_scale_factor) * Vbase_fullscale2[volbase2]) >> 8) - yCursorsSnap[A2];
						for(int a=val1; a<=val2; a++) { if(a>=0 && a<=200) { LCD_Buffer[2*a]=0x7F; LCD_Buffer[2*a+1]=0xFF; } }
					}
					if(wavesSnap[A1]) {
						if(Acquisition) {
							uint32_t sum = 0;
							for(int pos = p1; pos < p2; pos++) {
								sum += ch1Capture[pos];
							}
							float avg_float = (float)sum / (p2 - p1);
							if(avg_float < peakA1) peakA1 = avg_float;
							if(avg_float > peakA2) peakA2 = avg_float;
						} else {
							for(int pos=p1; pos<p2; pos++) {
								if(ch1Capture[pos]<peakA1) peakA1 = ch1Capture[pos];
								if(ch1Capture[pos]>peakA2) peakA2 = ch1Capture[pos];
							}
						}
						val1 = GRID_HEIGHT + ((int16_t)((peakA1 - ch1_scale_factor) * Vbase_fullscale1[volbase1]) >> 8) - yCursorsSnap[A1];
						val2 = GRID_HEIGHT + ((int16_t)((peakA2 - ch1_scale_factor) * Vbase_fullscale1[volbase1]) >> 8) - yCursorsSnap[A1];
						for(int a=val1; a<=val2; a++) { if(a>=0 && a<=200) { LCD_Buffer[2*a]=0xFF; LCD_Buffer[2*a+1]=0xE0; } }
					}
				} else {
					if(wavesSnap[A1]) {
						if(Acquisition) {
							uint32_t sum = 0;
							for(int pos = p1; pos < p2; pos++) {
								sum += ch1Capture[pos];
							}
							float avg_float = (float)sum / (p2 - p1);
							if(avg_float < peakA1) peakA1 = avg_float;
							if(avg_float > peakA2) peakA2 = avg_float;
						} else for(int pos=p1; pos<p2; pos++) {
							if(ch1Capture[pos]<peakA1) peakA1 = ch1Capture[pos];
							if(ch1Capture[pos]>peakA2) peakA2 = ch1Capture[pos];
						}
						val1 = GRID_HEIGHT + ((int16_t)((peakA1 - ch1_scale_factor) * Vbase_fullscale1[volbase1]) >> 8) - yCursorsSnap[A1];
						val2 = GRID_HEIGHT + ((int16_t)((peakA2 - ch1_scale_factor) * Vbase_fullscale1[volbase1]) >> 8) - yCursorsSnap[A1];
						for(int a=val1; a<=val2; a++) { if(a>=0 && a<=200) { LCD_Buffer[2*a]=0xFF; LCD_Buffer[2*a+1]=0xE0; } }
					}
					if(wavesSnap[A2]) {
						if(Acquisition) {
							uint32_t sum = 0;
							for(int pos = p1; pos < p2; pos++) { sum += ch2Capture[pos]; }
							float avg_float = (float)sum / (p2 - p1);
							if(avg_float < peakB1) peakB1 = avg_float;
							if(avg_float > peakB2) peakB2 = avg_float;
						} else for(int pos=p1; pos<p2; pos++) {
							if(ch2Capture[pos]<peakB1) peakB1 = ch2Capture[pos];
							if(ch2Capture[pos]>peakB2) peakB2 = ch2Capture[pos];
						}
						val1 = GRID_HEIGHT + ((int16_t)((peakB1 - ch2_scale_factor) * Vbase_fullscale2[volbase2]) >> 8) - yCursorsSnap[A2];
						val2 = GRID_HEIGHT + ((int16_t)((peakB2 - ch2_scale_factor) * Vbase_fullscale2[volbase2]) >> 8) - yCursorsSnap[A2];
						for(int a=val1; a<=val2; a++) { if(a>=0 && a<=200) { LCD_Buffer[2*a]=0x7F; LCD_Buffer[2*a+1]=0xFF; } }
					}
				}
			}
			//Draw grid:
			GRID_MARK(i);
			RenderLabels(i);
			LCD_FillBuffer(i, LCD_Buffer);
		}
	}
	else if(scale<1) {
		double delta0 = 0.0;
		double delta1;
		
		if (trigger_source % 2 != 0) {
			double denominator = (double)tgadc - ch1Capture[Index + 1];
			if (fabs(denominator) > 1e-9) {
				delta0 = ((double)ch1Capture[Index] - (double)tgadc) / (denominator * scale);
			}
		} else {
			double denominator = (double)tgadc - ch2Capture[Index + 1];
			if (fabs(denominator) > 1e-9) {
				delta0 = ((double)ch2Capture[Index] - (double)tgadc) / (denominator * scale);
			}
		}

		virIndex = old_virIndex - ((double)(tgpx+xCursor-old_pix))*scale;
		if(Hold) {
			double temp = GRID_WIDTH/2 - virIndex/scale;
			if(temp>32767) temp=32767; else if(temp<-32768) temp=-32768;
			trigger_pos_t = temp;
			if (trigger_pos_t<0) trigger_pos_t=0;
			if (trigger_pos_t>GRID_WIDTH) trigger_pos_t=GRID_WIDTH;
			trigger_pos_t -=3; // trigger pos Icon has 6pixel, 3 is a haft.
		}

		double px = ((double)tgpx - delta0) * scale;
		double j_offset = (int)px;
		delta1 = (1.0-(px-j_offset))/scale;
		if(px>j_offset) j_offset++;
		double j = (double)Index + virIndex - j_offset - GRID_WIDTH/2*scale;

		for(int i=0; i<=GRID_WIDTH; i++)
		{
			memset(LCD_Buffer, 0x00, sizeof(LCD_Buffer));
			if(peakA1<peakA2) {
				uint8_t tmp = peakA1;
				peakA1 = peakA2; peakA2 = tmp;
			}
			if(peakB1<peakB2) {
				uint8_t tmp = peakB1;
				peakB1 = peakB2; peakB2 = tmp;
			}

			double pos = ((double)i + delta1) * (double)scale;
			pos = pos - (int)pos;
			double offset = ((double)i + delta1) * (double)scale;
			uint16_t idx0 = (uint16_t)(j + (uint64_t)(offset));
			if (idx0+1 >= dynamic_size) {
				//Draw grid:
				GRID_MARK(i);
				RenderLabels(i);
				LCD_FillBuffer(i, LCD_Buffer);
				continue;
			}

			uint16_t x;
			double absolute_sample_pos = j + ((double)i + delta1) * scale;
			double time_ns = absolute_sample_pos * 8.0f;
			float interpolated_value_float;
			if(wavesSnap[A1]) {
				//uint16_t x = ch2Capture[idx0]+(ch2Capture[idx0+1]-ch2Capture[idx0])*pos;
				float x = sinc_interpolate_uint8(ch1Capture, dynamic_size, time_ns);
				if(x<peakA1) peakA1 = x;
				if(x>peakA2) peakA2 = x;
			}
			if(wavesSnap[A2]) {
				//uint16_t x = ch2Capture[idx0]+(ch2Capture[idx0+1]-ch2Capture[idx0])*pos;
				float x = sinc_interpolate_uint8(ch2Capture, dynamic_size, time_ns);
				if(x<peakB1) peakB1 = x;
				if(x>peakB2) peakB2 = x;
			}

			if (trigger_source%2==1) {
				if(wavesSnap[A2])
				{
					val1 = GRID_HEIGHT + ((int16_t)((peakB1-ch2_scale_factor)*Vbase_fullscale2[volbase2])>>8) - yCursorsSnap[A2];
					val2 = GRID_HEIGHT + ((int16_t)((peakB2-ch2_scale_factor)*Vbase_fullscale2[volbase2])>>8) - yCursorsSnap[A2];
					for(int a=val1; a<=val2; a++) { if(a>=0 && a<=200) { LCD_Buffer[2*a]=0x7F; LCD_Buffer[2*a+1]=0xFF; } }
				}
				if(wavesSnap[A1])
				{
					val1 = GRID_HEIGHT + ((int16_t)((peakA1-ch1_scale_factor)*Vbase_fullscale1[volbase1])>>8) - yCursorsSnap[A1];
					val2 = GRID_HEIGHT + ((int16_t)((peakA2-ch1_scale_factor)*Vbase_fullscale1[volbase1])>>8) - yCursorsSnap[A1];
					for(int a=val1; a<=val2; a++) { if(a>=0 && a<=200) { LCD_Buffer[2*a]=0xFF; LCD_Buffer[2*a+1]=0xE0; } }
				}
			} else {
				if(wavesSnap[A1])
				{
					val1 = GRID_HEIGHT + ((int16_t)((peakA1-ch1_scale_factor)*Vbase_fullscale1[volbase1])>>8) - yCursorsSnap[A1];
					val2 = GRID_HEIGHT + ((int16_t)((peakA2-ch1_scale_factor)*Vbase_fullscale1[volbase1])>>8) - yCursorsSnap[A1];
					for(int a=val1; a<=val2; a++) { if(a>=0 && a<=200) { LCD_Buffer[2*a]=0xFF; LCD_Buffer[2*a+1]=0xE0; } }
				}
				if(wavesSnap[A2])
				{
					val1 = GRID_HEIGHT + ((int16_t)((peakB1-ch2_scale_factor)*Vbase_fullscale2[volbase2])>>8) - yCursorsSnap[A2];
					val2 = GRID_HEIGHT + ((int16_t)((peakB2-ch2_scale_factor)*Vbase_fullscale2[volbase2])>>8) - yCursorsSnap[A2];
					for(int a=val1; a<=val2; a++) { if(a>=0 && a<=200) { LCD_Buffer[2*a]=0x7F; LCD_Buffer[2*a+1]=0xFF; } }
				}
			}
			//Draw grid:
			GRID_MARK(i);
			RenderLabels(i);
			LCD_FillBuffer(i, LCD_Buffer);
		}
	}
}

void SEARCH_TRIGGER_POINT(uint8_t over_sample) {
	//Search trigger point:
	if (XY_MODE==0)
	{
		Index = dynamic_size /2;  //Set vị trí bắt đầu tìm kiếm trigger ở giữa buffer.    
		if (trigger_source % 2 == 1) { // CH1
			float adc_per_volt = (PixelPerDIV * 256.0f) / (Vbase_fullscale1[volbase1] * VolPerDIV[volbase1]);
			float adc_zero = Z_offset1[volbase1] / 8.0f;
			tgadc = (int16_t)roundf(adc_zero - (tgvol1 * adc_per_volt));
		} else { // CH2
			float adc_per_volt = (PixelPerDIV * 256.0f) / (Vbase_fullscale2[volbase2] * VolPerDIV[volbase2]);
			float adc_zero = Z_offset2[volbase2] / 8.0f;
			tgadc = (int16_t)roundf(adc_zero - (tgvol2 * adc_per_volt));
		}
		uint16_t count_margin = tgpx*over_sample+20;//adc
		holdoff = 120;
		uint16_t count_max = Index-count_margin, count = 0, pointer  = 0;

		uint8_t* target_buffer = (trigger_source % 2 == 1) ? ch1Capture : ch2Capture;
		int direction = (trigger_source <= 2) ? 1 : -1;  // 1: falling edge, -1: rising edge

		switch (trigger_source)
		{
			case 1:
				while(count<stop)
				{
					pointer = Index-count;
					if((ch1Capture[pointer-1] > trigger_adc) && (ch1Capture[pointer] <= trigger_adc))
					{
						uint32_t sumhold_n=0,sumhold_p=0;
						for (uint16_t i = 0; i < holdoff; i++)
						{
							sumhold_n += ch1Capture[pointer-i];
							sumhold_p += ch1Capture[pointer+i];
						}
						if(sumhold_n>sumhold_p) {Index = pointer; break;}
					}
					pointer = Index+count + 1;
					if((ch1Capture[pointer-1] > trigger_adc) && (ch1Capture[pointer] <= trigger_adc))
					{
						uint32_t sumhold_n=0,sumhold_p=0;
						for (uint16_t i = 0; i < holdoff; i++)
						{
							sumhold_n += ch1Capture[pointer-i];
							sumhold_p += ch1Capture[pointer+i];
						}
						if(sumhold_n>sumhold_p) {Index = pointer; break;}
					}
					count++;
				}
				break;
			case 2:
				while(count<stop)
				{
					pointer = Index-count;
					if((ch2Capture[pointer-1] > trigger_adc) && (ch2Capture[pointer] <= trigger_adc))
					{
						uint32_t sumhold_n=0,sumhold_p=0;
						for (uint16_t i = 0; i < holdoff; i++)
						{
							sumhold_n += ch2Capture[pointer-i];
							sumhold_p += ch2Capture[pointer+i];
						}
						if(sumhold_n>sumhold_p) {Index = pointer; break;}
					}
					pointer = Index+count + 1;
					if((ch2Capture[pointer-1] > trigger_adc) && (ch2Capture[pointer] <= trigger_adc))
					{
						uint32_t sumhold_n=0,sumhold_p=0;
						for (uint16_t i = 0; i < holdoff; i++)
						{
							sumhold_n += ch2Capture[pointer-i];
							sumhold_p += ch2Capture[pointer+i];
						}
						if(sumhold_n>sumhold_p) {Index = pointer; break;}
					}
					count++;
				}
				break;
			case 3:
				while(count<stop)
				{
					pointer = Index-count;
					if((ch1Capture[pointer-1] < trigger_adc) && (ch1Capture[pointer] >= trigger_adc))
					{
						uint32_t sumhold_n=0,sumhold_p=0;
						for (uint16_t i = 0; i < holdoff; i++)
						{
							sumhold_n += ch1Capture[pointer-i];
							sumhold_p += ch1Capture[pointer+i];
						}
						if(sumhold_n<sumhold_p) {Index = pointer; break;}
					}
					pointer = Index+count + 1;
					if((ch1Capture[pointer-1] < trigger_adc) && (ch1Capture[pointer] >= trigger_adc))
					{
						uint32_t sumhold_n=0,sumhold_p=0;
						for (uint16_t i = 0; i < holdoff; i++)
						{
							sumhold_n += ch1Capture[pointer-i];
							sumhold_p += ch1Capture[pointer+i];
						}
						if(sumhold_n<sumhold_p) {Index = pointer; break;}
					}
					count++;
				}
				break;
			case 4:
				while(count<stop)
				{
					pointer = Index-count;
					if((ch2Capture[pointer-1] < trigger_adc) && (ch2Capture[pointer] >= trigger_adc))
					{
						uint32_t sumhold_n=0,sumhold_p=0;
						for (uint16_t i = 0; i < holdoff; i++)
						{
							sumhold_n += ch2Capture[pointer-i];
							sumhold_p += ch2Capture[pointer+i];
						}
						if(sumhold_n<sumhold_p) {Index = pointer; break;}
					}
					pointer = Index+count + 1;
					if((ch2Capture[pointer-1] < trigger_adc) && (ch2Capture[pointer] >= trigger_adc))
					{
						uint32_t sumhold_n=0,sumhold_p=0;
						for (uint16_t i = 0; i < holdoff; i++)
						{
							sumhold_n += ch2Capture[pointer-i];
							sumhold_p += ch2Capture[pointer+i];
						}
						if(sumhold_n<sumhold_p) {Index = pointer; break;}
					}
					count++;
				}
				break;
		}
	}

	if(Index<=tgpx*over_sample+20 || Index>CAPTURE_N_SAMPLES-tgpx*over_sample-20) Index = CAPTURE_N_SAMPLES/2; //margin 20
	
	trigger_point = Index;

	float flt;//Bvol
	#ifdef VERSION_1_1
	if (trigger_source%2==1)
	{
		flt=tgvol1;
		Stats_color = YELLOW;
		printFloat(250, 2, flt, 5, 1, Font_7x10, Stats_color, BGR); //260
		LCD_WriteString(210,2, "CH1", Font_7x10, Stats_color, BGR); //220
		LCD_WriteString(285,2, "V", Font_7x10, Stats_color, BGR); //295
	}
	else
	{
		flt=tgvol2;
		Stats_color = CYAN;
		printFloat(250, 2, flt, 5, 1, Font_7x10, Stats_color, BGR);
		LCD_WriteString(210,2, "CH2", Font_7x10, Stats_color, BGR);
		LCD_WriteString(285,2, "V", Font_7x10, Stats_color, BGR);
	}
	#else
	if (trigger_source%2==1)
	{
		flt=tgvol1;
		Stats_color = YELLOW;
		printFloat(260, 2, flt, 5, 1, Font_7x10, Stats_color, BGR);
		LCD_WriteString(220,2, "CH1", Font_7x10, Stats_color, BGR);
		LCD_WriteString(295,2, "V", Font_7x10, Stats_color, BGR);
	}
	else
	{
		flt=tgvol2;
		Stats_color = CYAN;
		printFloat(260, 2, flt, 5, 1, Font_7x10, Stats_color, BGR);
		LCD_WriteString(220,2, "CH2", Font_7x10, Stats_color, BGR);
		LCD_WriteString(295,2, "V", Font_7x10, Stats_color, BGR);
	}
	#endif
	//LCD_WriteNumber(2, 150, IDE, WHITE, BGR);
	DRAW_TRIGGER_ICON();
}

void SET_FREQ_ADC(uint freq) {
	pio_sm_set_enabled(pio, sm, false);
    pio_sm_clear_fifos(pio, sm);
    pio_sm_restart(pio, sm);
	float clockDiv;//= (float)clock_get_hz(clk_sys) / (float)(freq * 2);
	if(OSC) {
		switch (timebase)
		{
		case 0: //5Hz/div
			clockDiv=50; skip = 8;
			set_sys_clock_khz(250000, true);
			adc_capture_x1000_program_init(pio, sm, offset1000, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 1: //10Hz/div
			clockDiv=25; skip = 8;
			set_sys_clock_khz(250000, true);
			adc_capture_x1000_program_init(pio, sm, offset1000, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 2: //20Hz/div
			clockDiv=125; skip = 8;
			set_sys_clock_khz(250000, true);
			adc_capture_x100_program_init(pio, sm, offset100, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 3: //50Hz/div
			clockDiv=50; skip = 8;
			set_sys_clock_khz(250000, true);
			adc_capture_x100_program_init(pio, sm, offset100, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 4: //100Hz/div
			clockDiv=25; skip = 8;
			set_sys_clock_khz(250000, true);
			adc_capture_x100_program_init(pio, sm, offset100, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 5: //200Hz/div
			clockDiv=125; skip = 8;
			set_sys_clock_khz(250000, true);
			adc_capture_x10_program_init(pio, sm, offset10, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 6: //500Hz/div
			clockDiv=50; skip = 8;
			set_sys_clock_khz(250000, true);
			adc_capture_x10_program_init(pio, sm, offset10, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 7: //1kHz/div
			clockDiv=25; skip = 8;
			set_sys_clock_khz(250000, true);
			adc_capture_x10_program_init(pio, sm, offset10, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 8: //2.5kHz/div
			clockDiv=125; skip = 8;
			set_sys_clock_khz(250000, true);
			adc_capture_program_init(pio, sm, offset, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 9: //5kHz/div
			clockDiv=50; skip = 8;
			set_sys_clock_khz(250000, true);
			adc_capture_program_init(pio, sm, offset, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 10: //10kHz/div
			clockDiv=25; skip = 4;
			set_sys_clock_khz(250000, true);
			adc_capture_program_init(pio, sm, offset, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 11: //25kHz/div
			clockDiv=25; skip = 4;
			set_sys_clock_khz(250000, true);
			adc_capture_program_init(pio, sm, offset, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 12: //50kHz/div
			clockDiv=10; skip = 4;
			set_sys_clock_khz(250000, true);
			adc_capture_program_init(pio, sm, offset, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 13: //100kHz/div
			clockDiv=10; skip = 4;
			set_sys_clock_khz(250000, true);
			adc_capture_program_init(pio, sm, offset, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 14: //250kHz/div
			clockDiv=5; skip = 4;
			set_sys_clock_khz(250000, true);
			adc_capture_program_init(pio, sm, offset, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 15: //500kHz/div
			clockDiv=5; skip = 2;
			set_sys_clock_khz(250000, true);
			adc_capture_program_init(pio, sm, offset, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 16: //1MHz/div
			clockDiv=2; skip = 1;
			set_sys_clock_khz(200000, true);
			adc_capture_program_init(pio, sm, offset, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 17: //2.5MHz/div
			clockDiv=2; skip = 2;
			set_sys_clock_khz(200000, true);
			adc_capture_program_init(pio, sm, offset, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 18: //5MHz/div
			clockDiv=1; skip = 1;
			set_sys_clock_khz(250000, true);
			adc_capture_program_init(pio, sm, offset, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		default:
			break;
		}
	} else {
		switch (timebase)
		{
		case 0: //5Hz/div
			clockDiv=25; skip = 32;
			set_sys_clock_khz(192000, true);
			adc_capture_x1000_program_init(pio, sm, offset1000, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 1: //10Hz/div
			clockDiv=125; skip = 32;
			set_sys_clock_khz(192000, true);
			adc_capture_x100_program_init(pio, sm, offset100, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 2: //20Hz/div
			clockDiv=50; skip = 32;
			set_sys_clock_khz(192000, true);
			adc_capture_x100_program_init(pio, sm, offset100, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 3: //50Hz/div
			clockDiv=25; skip = 32;
			set_sys_clock_khz(192000, true);
			adc_capture_x100_program_init(pio, sm, offset100, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 4: //100Hz/div
			clockDiv=125; skip = 32;
			set_sys_clock_khz(192000, true);
			adc_capture_x10_program_init(pio, sm, offset10, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 5: //200Hz/div
			clockDiv=50; skip = 32;
			set_sys_clock_khz(192000, true);
			adc_capture_x10_program_init(pio, sm, offset10, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 6: //500Hz/div
			clockDiv=25; skip = 32;
			set_sys_clock_khz(192000, true);
			adc_capture_x10_program_init(pio, sm, offset10, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 7: //1kHz/div
			clockDiv=125; skip = 32;
			set_sys_clock_khz(192000, true);
			adc_capture_program_init(pio, sm, offset, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 8: //2.5kHz/div
			clockDiv=50; skip = 32;
			set_sys_clock_khz(192000, true);
			adc_capture_program_init(pio, sm, offset, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 9: //5kHz/div
			clockDiv=25; skip = 32;
			set_sys_clock_khz(192000, true);
			adc_capture_program_init(pio, sm, offset, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 10: //10kHz/div
			clockDiv=125; skip = 4;
			set_sys_clock_khz(240000, true);
			adc_capture_program_init(pio, sm, offset, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 11: //25kHz/div
			clockDiv=50; skip = 4;
			set_sys_clock_khz(240000, true);
			adc_capture_program_init(pio, sm, offset, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 12: //50kHz/div
			clockDiv=25; skip = 4;
			set_sys_clock_khz(240000, true);
			adc_capture_program_init(pio, sm, offset, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 13: //100kHz/div
			clockDiv=10; skip = 4;
			set_sys_clock_khz(192000, true);
			adc_capture_program_init(pio, sm, offset, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 14: //250kHz/div
			clockDiv=5; skip = 4;
			set_sys_clock_khz(240000, true);
			adc_capture_program_init(pio, sm, offset, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 15: //500kHz/div
			clockDiv=5; skip = 2;
			set_sys_clock_khz(240000, true);
			adc_capture_program_init(pio, sm, offset, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 16: //1MHz/div
			clockDiv=5; skip = 1;
			set_sys_clock_khz(240000, true);
			adc_capture_program_init(pio, sm, offset, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 17: //2.5MHz/div
			clockDiv=1; skip = 2;
			set_sys_clock_khz(240000, true);
			adc_capture_program_init(pio, sm, offset, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		case 18: //5MHz/div
			clockDiv=1; skip = 1;
			set_sys_clock_khz(240000, true);
			adc_capture_program_init(pio, sm, offset, clockDiv, CAPTURE_DATA_BASE, CAPTURE_CLK_BASE);
			break;
		default:
			break;
		}
	}
	pio_sm_set_enabled(pio, sm, true);
}

void DRAW_WAVE_POS_ICON(void)
{
	if(wavesOld[A2])
	{
		DRAW_WAVE_TAG(old_zeropos_A2, BGR, Channel_B);
	}
	if(wavesOld[A1])
	{
		DRAW_WAVE_TAG(old_zeropos_A1, BGR, Channel_A);
	}
	if (trigger_source==1)
	{
		if (show_mode!=2)
		{
			val2 = GRID_HEIGHT + WindowOfset_Y - yCursorsSnap[A2]; old_zeropos_A2=val2;
			if(wavesSnap[A2])
			{
				DRAW_WAVE_TAG(val2, CYAN, Channel_B);
			}
		}
		wavesOld[A2] = wavesSnap[A2];
		if (show_mode<3)
		{
			val1 = GRID_HEIGHT + WindowOfset_Y - yCursorsSnap[A1]; old_zeropos_A1=val1;
			if(wavesSnap[A1] && show_mode<3)
			{
				DRAW_WAVE_TAG(val1, YELLOW, Channel_A);
			}
		}
		wavesOld[A1] = wavesSnap[A1];
	}
	else
	{
		if (show_mode<3)
		{
			val1 = GRID_HEIGHT + WindowOfset_Y - yCursorsSnap[A1]; old_zeropos_A1=val1;
			if(wavesSnap[A1] && show_mode<3)
			{
				DRAW_WAVE_TAG(val1, YELLOW, Channel_A);
			}
		}
		wavesOld[A1] = wavesSnap[A1];
		if (show_mode!=2)
		{
			val2 = GRID_HEIGHT + WindowOfset_Y - yCursorsSnap[A2]; old_zeropos_A2=val2;
			if(wavesSnap[A2])
			{
				DRAW_WAVE_TAG(val2, CYAN, Channel_B);
			}
		}
		wavesOld[A2] = wavesSnap[A2];
	}
}

void DRAW_TRIGG_PosXY(void)
{
	if (trigger_source%2==1) {
        trigger_pos_y = (uint16_t)roundf((tgvol1 * PixelPerDIV / VolPerDIV[volbase1]) + yCursors[A1]);
    } else {
        trigger_pos_y = (uint16_t)roundf((tgvol2 * PixelPerDIV / VolPerDIV[volbase2]) + yCursors[A2]);
    }
	// Ngang:
	DRAW_TRG_PosY(GRID_HEIGHT-old_trigger_pos_y, BGR);
	trigger_pos_drawing=trigger_pos_y;
	if (trigger_pos_drawing<0) trigger_pos_drawing=0;
	if (trigger_pos_drawing>GRID_HEIGHT) trigger_pos_drawing=GRID_HEIGHT;
	DRAW_TRG_PosY(GRID_HEIGHT-trigger_pos_drawing, WHITE);
	old_trigger_pos_y = trigger_pos_drawing;
}

void DRAW_TRIGGER_ICON(void) {
	if (trigger_source%2==0) trigger_color = CYAN; else  trigger_color = YELLOW;
	#ifdef VERSION_1_1
	if (trigger_source>2)
	{
		DRAW_TRG(235,2, trigger_color,Trigger_UP);  //245
	}
	else
	{
		DRAW_TRG(235,2, trigger_color,Trigger_DWN);
	}
	#else
	if (trigger_source>2)
	{
		DRAW_TRG(245,2, trigger_color,Trigger_UP);
	}
	else
	{
		DRAW_TRG(245,2, trigger_color,Trigger_DWN);
	}
	#endif
}

void DRAW_PANEL(uint16_t x, uint16_t y, uint16_t bgr) {
	LCD_FillRectangle(x,y,50,11, bgr);
}

uint16_t PCF8575_readButton16() {
	uint8_t input[2]={0xFF,0xFF};
	#ifdef CAT9555
	uint8_t reg = 0x00;  // Input Port 0
	i2c_write_blocking(i2c0, 0x20, &reg, 1, true);// Gửi địa chỉ thanh ghi để đọc
	i2c_read_blocking(i2c0, 0x20, input, 2, false);// Đọc 2 byte (Port 0 + Port 1)
	#else
	i2c_read_blocking(i2c0, 0x20, input, 2, true);
	#endif
	return (uint16_t)input[1]<<8 | input[0];
}


uint8_t BIT_REVERSE (uint16_t value, uint8_t ch) {
	uint8_t raw;
	if(ch) raw = value >> 8;
	else
	{
		raw = value & 0xFF;
		//Bit reverse
		raw = (raw & 0xF0) >> 4 | (raw & 0x0F) << 4;
		raw = (raw & 0xCC) >> 2 | (raw & 0x33) << 2;
		raw = (raw & 0xAA) >> 1 | (raw & 0x55) << 1;
	}
	return raw;
}

void process_buttons(uint16_t button) {
	static uint16_t debounce[NUM_BUTTONS] = {0};
	static uint8_t pressed[NUM_BUTTONS] = {0};
	//static uint8_t long_pressed[NUM_BUTTONS] = {0};
    for (int i = 0; i < NUM_BUTTONS; i++) {
        if ((button & button_mask[i]) == 0) {  // Nút đang nhấn
            if (debounce[i] < BT_HOLD) {
                debounce[i]++;
            }

            if (debounce[i] == BT_PRESSED_SHORT && !pressed[i]) {
                handle_button_short_press(i);
                pressed[i] = 1;
				config_id=100;
            }

            if (debounce[i] == BT_HOLD /*&& !long_pressed[i]*/) {
                handle_button_long_press(i);
				debounce[i] -=100;
                //long_pressed[i] = 1;
				config_id=100;
            }
        } else {
            debounce[i] = 0;
            pressed[i] = 0;
			//long_pressed[i] = 0;
        }
    }
}

void handle_button_short_press(uint16_t button) {
	switch (button) {
	case 4: { //ENCODER SW
			if(range_cursor == CH1) {
				CH1_Opto = (CH1_Opto != CH1_DC) ? CH1_DC : CH1_AC;
			} else {
				CH2_Opto = (CH2_Opto != CH2_DC) ? CH2_DC : CH2_AC;
			}
			vRange_change = 20;
		}
		break;
	case 5: {
			if(Hold==0) Hold=1;
			else {Hold=0;xCursor=0;virIndex=0;old_virIndex=0;old_pix=0;}//old_virIndex=0;
			vRange_change=17; //flag to change color
		}
		break;
	case 6: {
			if(calib_mode==0)
			{
				critical_section_enter_blocking(&my_lock);
				if(MODE==1) MODE=2; else MODE=1;
				critical_section_exit(&my_lock);
				if(range_cursor==CH1) FFT_CH=1;
				if(range_cursor==CH2) FFT_CH=2;
				if(timebase>18) timebase=18;
				config_id=100;
				//if(menu_label) menu_label=false; else menu_label=true;
			}
			else if(calib_mode==1) {if(show_mode==2) {show_mode=3;range_cursor=CH2;Stats_source=2; } else {calib_mode = 0;Save_calib=true;}}
			else if(calib_mode==5) {MENU=7; timebase=17; show_mode=2; Hold=0; range_cursor=CH1;Stats_source=1; calib_mode = 1;MODE=1;calib_cursor=false;}
			vRange_change=36;
		}
		break;
	case 7: { //TRIGG
			if(MODE==1) MENU = 5;
			vRange_change=10; //flag to change color6
		}
		break;
	case 8: { //Show mode
			if(MODE==1) MENU = 4;
			vRange_change=18; //flag to change color
		}
		break;
	case 9: { //CH1/CH2
			if(MODE==1) {
				if (MENU != 3) {
					MENU = 3;
					if(show_mode==2) {range_cursor = CH1;position_wave = 0;}
					if(show_mode==3) {range_cursor = CH2;position_wave = 1;}
				}
				else if (show_mode == 1)
				{
					if (range_cursor == CH1) {
						range_cursor = CH2;
						position_wave = 1;
					} else {
						range_cursor = CH1;
						position_wave = 0;
					}
				}
			}
			else {
				if(FFT_CH==1) {FFT_CH=2;range_cursor=CH2;}
				else {FFT_CH=1;range_cursor=CH1;}
			}
			vRange_change = 15;
		}
		break;
	case 10:{//BTN_LEFT
			switch (MENU)
			{
			case 3:
				if(show_mode!=3) position_wave=0;
				break;
			case 4: //SHOW = CH1
				show_mode = 2;
				Stats_source = 1;
				range_cursor = CH1;
				if      (trigger_source==2) {trigger_source=1;trigger_pos_y = trigger_pos_y*VolPerDIV[volbase2]/VolPerDIV[volbase1];}   
				else if (trigger_source==4) {trigger_source=3;trigger_pos_y = trigger_pos_y*VolPerDIV[volbase2]/VolPerDIV[volbase1];}
				break;
			case 5:  //TRIGG
				if (show_mode<3)
				{
					if      (trigger_source==2) {trigger_source=1;trigger_pos_y = trigger_pos_y*VolPerDIV[volbase2]/VolPerDIV[volbase1];}
					else if (trigger_source==4) {trigger_source=3;trigger_pos_y = trigger_pos_y*VolPerDIV[volbase2]/VolPerDIV[volbase1];}
				}
				else
				{
					if      (trigger_source==1) {trigger_source=2;trigger_pos_y = trigger_pos_y*VolPerDIV[volbase1]/VolPerDIV[volbase2];}   
					else if (trigger_source==3) {trigger_source=4;trigger_pos_y = trigger_pos_y*VolPerDIV[volbase1]/VolPerDIV[volbase2];}
				}
				break;
			case 6:
				if(tgpx>-150)  tgpx--;
				break;
			default:
				break;
			}
			vRange_change=20; //flag to change color
		}
		break;
	case 11:{ //BTN_DWN
			switch (MENU)
			{
			case 3:
				if (yCursors[position_wave]>0) yCursors[position_wave]-=1; 
				break;
			case 4: //SHOW = CH1 + CH2
				show_mode = 1;
				Stats_source=2;
				break;
			case 5:   //TRIGG
				if      (trigger_source==1) trigger_source=3;
				else if (trigger_source==2) trigger_source=4;
				break;
			case 6:  //TRG_pos  
				if (trigger_source%2==1)
				{
					trigger_pos_y = yCursors[A1] + (tgvol1 * PixelPerDIV / VolPerDIV[volbase1]);
					if(trigger_pos_y>0)  tgvol1-=VolPerDIV[volbase1]/PixelPerDIV;
				}
				else
				{
					trigger_pos_y = yCursors[A2] + (tgvol2 * PixelPerDIV / VolPerDIV[volbase2]);
					if(trigger_pos_y>0)  tgvol2-=VolPerDIV[volbase2]/PixelPerDIV;
				}
				break;
			case 7:
				switch (show_mode)
				{
				case 2:
					if(calib_cursor) Vbase_fullscale1[volbase1] -=1;
					else Z_offset1[volbase1] -=1;
					break;
				case 3:
					if(calib_cursor) Vbase_fullscale2[volbase2] -=1;
					else Z_offset2[volbase2] -=1;
					break;
				default:
					break;
				}
				break;
			default:
				break;
			}
			vRange_change=23; //flag to change color
		}
		break;
	case 12:{ //BTN_CTR
			if(MODE==1) {
				if(calib_mode==1) {
					if(calib_cursor) calib_cursor=false; else calib_cursor=true;
				}
				else if(Acquisition) Acquisition = false; else Acquisition = true;
			}
			if(MODE==2) {
				if(window_type<4) window_type++; else window_type=0;
			}
		}
		break;
	case 13:{ //BTN_UP
			switch (MENU)
			{
			case 3:
				if (yCursors[position_wave]<GRID_HEIGHT) yCursors[position_wave]+=1; 
				break;
			case 4: //SHOW = CH1 + CH2
				show_mode = 1;
				Stats_source=1;
				break;
			case 5:   //TRIGG
				if 		(trigger_source==3) trigger_source=1;
				else if (trigger_source==4) trigger_source=2;
				break;
			case 6:  //TRG_pos  
				if (trigger_source%2==1)
				{
					trigger_pos_y = yCursors[A1] + (tgvol1 * PixelPerDIV / VolPerDIV[volbase1]);
					if(trigger_pos_y<GRID_HEIGHT)  tgvol1+=VolPerDIV[volbase1]/PixelPerDIV;
				}
				else
				{
					trigger_pos_y = yCursors[A2] + (tgvol2 * PixelPerDIV / VolPerDIV[volbase2]);
					if(trigger_pos_y<GRID_HEIGHT)  tgvol2+=VolPerDIV[volbase2]/PixelPerDIV;
				}
				break;
			case 7:
				switch (show_mode)
				{
				case 2:
					if(calib_cursor) Vbase_fullscale1[volbase1] +=1;
					else Z_offset1[volbase1] +=1;
					break;
				case 3:
					if(calib_cursor) Vbase_fullscale2[volbase2] +=1;
					else Z_offset2[volbase2] +=1;
					break;
				default:
					break;
				}
				break;
			default:
				break;
			}
			vRange_change=22; //flag to change color
		}
		break;
	case 14:{  //Trig_Pos
			if(MODE==1) MENU = 6;
			vRange_change=19; //flag to change color
		}
		break;
	case 15:{ //BTN_RIGHT
			switch (MENU)
			{
			case 3:
			if(show_mode!=2) position_wave=1;
				break;
			case 4: //SHOW = CH2
				show_mode = 3;
				Stats_source = 2;
				range_cursor = CH2;
				if(trigger_source == 1 || trigger_source == 3) {
					if(trigger_source == 1) trigger_source = 2;
					else trigger_source = 4;
					trigger_pos_y = trigger_pos_y * VolPerDIV[volbase1] / VolPerDIV[volbase2];
				}
				break;
			case 5:  //TRIGG
				if (show_mode!=2)
				{
					if      (trigger_source==1) {trigger_source=2;trigger_pos_y = trigger_pos_y*VolPerDIV[volbase1]/VolPerDIV[volbase2];}
					else if (trigger_source==3) {trigger_source=4;trigger_pos_y = trigger_pos_y*VolPerDIV[volbase1]/VolPerDIV[volbase2];}
				}
				else
				{
					if      (trigger_source==2) {trigger_source=1;trigger_pos_y = trigger_pos_y*VolPerDIV[volbase2]/VolPerDIV[volbase1];}   
					else if (trigger_source==4) {trigger_source=3;trigger_pos_y = trigger_pos_y*VolPerDIV[volbase2]/VolPerDIV[volbase1];}
				}
				break;
			case 6:
				if(tgpx<GRID_WIDTH/2)  tgpx++;
				break;
			default:
				break;
			}
			vRange_change=21; //flag to change color
		}
		break;
	
	default:
		break;
	}
}

void handle_button_long_press(uint8_t button) {
    switch (button)
	{
	case 12:
		Hold=0;
		break;
	case 10:
		switch (MENU)
		{
		case 6:
			if(tgpx > -150)  tgpx--;
			break;
		default:
			break;
		}
		break;
	case 15:
		switch (MENU)
		{
		case 6:
			if(tgpx < GRID_WIDTH/2)  tgpx++;
			break;
		default:
			break;
		}
		break;
	case 11:
		switch (MENU)
		{
		case 3:
			if (yCursors[position_wave]>0) yCursors[position_wave]-=1;
			break;
		case 6:
			if (trigger_source%2==1)
			{
				trigger_pos_y = yCursors[A1] + (tgvol1 * PixelPerDIV / VolPerDIV[volbase1]);
				if(trigger_pos_y>0)  tgvol1-=VolPerDIV[volbase1]/PixelPerDIV;
			}
			else
			{
				trigger_pos_y = yCursors[A2] + (tgvol2 * PixelPerDIV / VolPerDIV[volbase2]);
				if(trigger_pos_y>0)  tgvol2-=VolPerDIV[volbase2]/PixelPerDIV;
			}
			break;
		case 7:
			switch (show_mode)
			{
			case 2:
				if(calib_cursor) Vbase_fullscale1[volbase1] -=1;
				else Z_offset1[volbase1] -=1;
				break;
			case 3:
				if(calib_cursor) Vbase_fullscale2[volbase2] -=1;
				else Z_offset2[volbase2] -=1;
				break;
			default:
				break;
			}
			break;
		default:
			break;
		}
		break;
	case 13:
		switch (MENU)
		{
		case 3:
			if (yCursors[position_wave]<GRID_HEIGHT) yCursors[position_wave]+=1;
			break;
		case 6:
			if (trigger_source%2==1)
			{
				trigger_pos_y = yCursors[A1] + (tgvol1 * PixelPerDIV / VolPerDIV[volbase1]);
				if(trigger_pos_y<GRID_HEIGHT)  tgvol1+=VolPerDIV[volbase1]/PixelPerDIV;
			}
			else
			{
				trigger_pos_y = yCursors[A2] + (tgvol2 * PixelPerDIV / VolPerDIV[volbase2]);
				if(trigger_pos_y<GRID_HEIGHT)  tgvol2+=VolPerDIV[volbase2]/PixelPerDIV;
			}
			break;
		case 7:
			switch (show_mode)
			{
			case 2:
				if(calib_cursor) Vbase_fullscale1[volbase1] +=1;
				else Z_offset1[volbase1] +=1;
				break;
			case 3:
				if(calib_cursor) Vbase_fullscale2[volbase2] +=1;
				else Z_offset2[volbase2] +=1;
				break;
			default:
				break;
			}
			break;
		default:
			break;
		}
		break;
	default:
		break;
	}
}

int cmp_float(const void* a, const void* b) {
    float fa = *(const float*)a;
    float fb = *(const float*)b;
    return (fa > fb) - (fa < fb);
}

uint8_t movingAvg(uint8_t* buffer, int pos, int length) {
    int sum = 0;
    for (int j = -MOVING_AVG_SIZE / 2; j <= MOVING_AVG_SIZE / 2; j++) {
        int idx = pos + j;
        if (idx < 0) idx = 0;
        if (idx >= length) idx = length - 1;
        sum += buffer[idx];
    }
    return (uint8_t)(sum / MOVING_AVG_SIZE);
}

void RenderLabels(uint16_t pos) {
	if(calib_mode==1) {
		uint16_t cl1,cl2;
		if(calib_cursor) {cl1 = WHITE; cl2 = RED;} else {cl1 = RED; cl2 = WHITE;}
		LCD_RenderString(pos, 108, 86,  "OFFSET:     ", LCD_Buffer, Font_7x10, WHITE, BGR); LCD_RenderString(pos, 164, 86,   zcalib, LCD_Buffer, Font_7x10, cl1, BGR);
		LCD_RenderString(pos, 108, 100, "VOLCAL:     ", LCD_Buffer, Font_7x10, WHITE, BGR);LCD_RenderString(pos, 171, 100,  vcalib, LCD_Buffer, Font_7x10, cl2, BGR);
	}
	//if(Save_calib) LCD_RenderString(pos, 136, 93, "SAVE", LCD_Buffer, Font_7x10, WHITE, BGR);
}

void save_calibration_data(void) {
	uint16_t current_eeprom_addr = CALIB_BASE; // Assuming CALIB_BASE is defined in eeprom_24C256.h

    // Save Channel 1 Zero Offsets
    for (int i = 0; i < 7; i++) {
        uint8_t data[2] = {Z_offset1[i] >> 8, Z_offset1[i] & 0xFF};
        eeprom_write_bytes(current_eeprom_addr + i * 2, data, 2);
    }
    current_eeprom_addr += 7 * 2; // Move to next block

    // Save Channel 2 Zero Offsets
    for (int i = 0; i < 7; i++) {
        uint8_t data[2] = {Z_offset2[i] >> 8, Z_offset2[i] & 0xFF};
        eeprom_write_bytes(current_eeprom_addr + i * 2, data, 2);
    }
    current_eeprom_addr += 7 * 2; // Move to next block

    // Save Channel 1 Full Scale
    for (int i = 0; i < 7; i++) {
        uint8_t data = Vbase_fullscale1[i];
        eeprom_write_bytes(current_eeprom_addr + i, &data, 1);
    }
    current_eeprom_addr += 7; // Move to next block

    // Save Channel 2 Full Scale
    for (int i = 0; i < 7; i++) {
        uint8_t data = Vbase_fullscale2[i];
        eeprom_write_bytes(current_eeprom_addr + i, &data, 1);
    }
}

void load_calibration_data(void) {
	uint16_t current_eeprom_addr = CALIB_BASE;

    // Load Channel 1 Zero Offsets
    for (int i = 0; i < 7; i++) {
        uint8_t data[2];
        eeprom_read_bytes(current_eeprom_addr + i * 2, data, 2);
        Z_offset1[i] = (uint16_t)data[0] << 8 | data[1];
    }
    current_eeprom_addr += 7 * 2;

    // Load Channel 2 Zero Offsets
    for (int i = 0; i < 7; i++) {
        uint8_t data[2];
        eeprom_read_bytes(current_eeprom_addr + i * 2, data, 2);
        Z_offset2[i] = (uint16_t)data[0] << 8 | data[1];
    }
    current_eeprom_addr += 7 * 2;

    // Load Channel 1 Full Scale
    for (int i = 0; i < 7; i++) {
        uint8_t data;
        eeprom_read_bytes(current_eeprom_addr + i, &data, 1);
        Vbase_fullscale1[i] = data;
    }
    current_eeprom_addr += 7;

    // Load Channel 2 Full Scale
    for (int i = 0; i < 7; i++) {
        uint8_t data;
        eeprom_read_bytes(current_eeprom_addr + i, &data, 1);
        Vbase_fullscale2[i] = data;
    }
}


void DRAW_FFT(void) {
	/*
	                 Độ giảm đỉnh     Hệ số hiệu        Mức đỉnh sườn phụ        Đặc điểm chính
			           (Tối đa)      chỉnh biên độ           (tối đa)
	Hanning            -1.42 dB           2.0                 -31 dB             Đa dụng, cân bằng tốt nhất
	Flat Top         < -0.01 dB          ~4.55                -93 dB             Đo biên độ chính xác nhất
	Blackman-Harris    -0.83 dB          ~2.80                -92 dB             Dải động tốt nhất
	Hamming            -1.78 dB          ~1.85                -41 dB             Triệt tốt đỉnh sườn phụ gần nhất
	Rectangular        -3.92 dB           1.0                 -13 dB             Chỉ cho tín hiệu xung


	Bạn nhân hệ số hiệu chỉnh biên độ với kết quả biên độ bạn tính được từ FFT để có được giá trị biên độ thực của tín hiệu.
	*/
	double CORRECTION_FACTOR = 1.0;
	switch (window_type) {
		case 0: // HFT248D
			CORRECTION_FACTOR = 3.54;
			break;
		case 1: // Flat top
			CORRECTION_FACTOR = 4.64;
			break;
		case 2: // Blackman-Harris
			CORRECTION_FACTOR = 2.79;
			break;
		case 3: // Hamming
			CORRECTION_FACTOR = 1.85;
			break;
		case 4: // Hanning (von Hann)
			CORRECTION_FACTOR = 2.0;
			break;
		case 5: // Rectangular
			CORRECTION_FACTOR = 1.0;
			break;
	}


	double offset;
	if(FFT_CH==1) offset = (double)Z_offset1[volbase1] / 8.0; //-127.5
	else          offset = (double)Z_offset2[volbase2] / 8.0;

	for(uint16_t n = 0; n < N; n++) {
		double window_value = 0;
        // Calculate window function value
        switch (window_type) {
            case 0: // HFT248D
			{
				const double a0 = 0.28253812;
				const double a1 = 0.5;
				const double a2 = 0.21746188;
				double term1 = a1 * cos(2.0 * M_PI * n / (N - 1));
				double term2 = a2 * cos(4.0 * M_PI * n / (N - 1));
				window_value = a0 - term1 + term2;
                break;
			}
            case 1: // Flat top
			{
				const double a0 = 0.21557895;
				const double a1 = 0.41663158;
				const double a2 = 0.277263158;
				const double a3 = 0.083578947;
				const double a4 = 0.006947368;
				double term1 = a1 * cos(2.0 * M_PI * n / (N - 1));
				double term2 = a2 * cos(4.0 * M_PI * n / (N - 1));
				double term3 = a3 * cos(6.0 * M_PI * n / (N - 1));
				double term4 = a4 * cos(8.0 * M_PI * n / (N - 1));
                window_value = a0 - term1 + term2 - term3 + term4;
                break;
			}
            case 2: // Blackman-Harris
			{
				const double a0 = 0.35875;
				const double a1 = 0.48829;
				const double a2 = 0.14128;
				const double a3 = 0.01168;
                double term1 = a1 * cos(2.0 * M_PI * n / (N - 1));
				double term2 = a2 * cos(4.0 * M_PI * n / (N - 1));
				double term3 = a3 * cos(6.0 * M_PI * n / (N - 1));
				window_value = a0 - term1 + term2 - term3;
                break;
			}
            case 3: // Hamming
				//a0 = 0.53836 a1 = 0.46164
                window_value = 0.54 - 0.46 * cos(2.0 * M_PI * n / (N - 1));
                break;
            case 4: // Hanning (von Hann)
                window_value = 0.5 * (1 - cos(2 * M_PI * n / (N - 1)));
                break;
			case 5: // Rectangular
				window_value = 1.0;
				break;
        }
		//Chuẩn hóa giá trị ADC:
		if(FFT_CH==1) real[n] = (double)ch1Capture[n*skip] - offset; //-127.5
		else          real[n] = (double)ch2Capture[n*skip] - offset;
		real[n] *= window_value;
	}

	RFFT(N, true, CORRECTION_FACTOR, real);

	Harmonic_t myHarmonics[2];
	find_harmonics(N, Mag, myHarmonics);



	//SFDR: dBc
	#define EPSILON 1e-9
	double cleanliness = 20.0 * log10f(myHarmonics[1].Amplitude/myHarmonics[0].Amplitude);
	FFT.sfdr += cleanliness;

	//THD: %
	double fundamental = myHarmonics[0].Amplitude;
	double thd_sum = 0.0;
	for (int h = 2; h <= 10; h++) {
		int harmonic_bin = (int)(myHarmonics[0].Index * h + 0.5);
		if (harmonic_bin >= N/2) break; // tránh vượt giới hạn FFT
		thd_sum += Mag[harmonic_bin] * Mag[harmonic_bin];
	}
	double thd_percent = (sqrt(thd_sum) / fundamental) * 100.0;
	FFT.tdh += thd_percent;
	

	// Biên độ AC lớn nhất có thể có của hệ thống
	const double FULL_SCALE_AMPLITUDE = 127.5; 
	// Dải động bạn muốn hiển thị trên màn hình (ví dụ: 120 dB)
	const double DYNAMIC_RANGE_DB = 80.0; 
	// Chiều cao của khu vực vẽ đồ thị (ví dụ: 200 pixel)
	const double SCREEN_HEIGHT_PX = 200.0;
	//if(myHarmonics[0].Amplitude<127.5) myHarmonics[0].Amplitude = 127.5;
	//Decibels relative to Full Scale: dBFS
	for (int i = 2; i < N/2; i++) {
		double mag = Mag[i];
		if (mag < 1e-9) mag = 1e-9; // Sàn nhiễu để tránh log(0)

		// Bước 1: Tính giá trị dBFS (so sánh với mức full scale)
    	double dbfs = 20.0 * log10(mag / FULL_SCALE_AMPLITUDE);

		// Bước 2: Chuyển giá trị dBFS sang tọa độ Y trên màn hình
		// Mức 0 dBFS sẽ ở trên cùng (y=0)
		// Mức -120 dBFS sẽ ở dưới cùng (y=200)
		double display_y = SCREEN_HEIGHT_PX * (dbfs / -DYNAMIC_RANGE_DB);


		if (display_y > 200.0) display_y = 200.0;
    	if (display_y < 0.0) display_y = 0.0;
		Mag[i] = display_y;
	}
	//Hoặc peakMag tính chuẩn fixedScale:
	//float A = (255-127)*0.00390624f;  //Biên độ sau chuẩn hóa ADC: A = ±0.496
	//FFT sẽ "quét" qua các tần số. Khi nó quét đến đúng tần số của sóng sin, các phép nhân và cộng bên trong thuật toán sẽ cộng hưởng với nhau.
	//Quá trình cộng dồn trên N mẫu này tạo ra một sự khuếch đại (gain). Đối với các thành phần AC, độ khuếch đại này là N/2.
	//gain = N/2;
	//peakMag = A*N/2;

	// Tính tần số tương ứng
	float frequency_resolution = sampling_rate[timebase]/(float)N;
	float frq = myHarmonics[0].Index * frequency_resolution;
	FFT.freq += frq;
	FFT.count++;


	



	uint16_t pos0 = 0, pos1 = 0, top = 0, bottom = 0;
	double X0, X1, xmin, xmax, a, b;
	double x = 0;
	xmin = 	1;//start bin
	xmax = N/2-1;//bin at pixel 300
	X0   = 0;
	X1   = GRID_WIDTH; //WIDTH
	b    = (X1 - X0) / log(xmax / xmin);
	a    = X0 - b * log(xmin);

	
	top    = Mag[0];
	bottom = Mag[0];
	trigger_pos_drawing=tgpx;  //150
	trigger_pos_t = GRID_WIDTH/2 + (tgpx+xCursor);
	if (trigger_pos_t<0) trigger_pos_t=0;
	if (trigger_pos_t>GRID_WIDTH) trigger_pos_t=GRID_WIDTH;
	trigger_pos_t -=3; // trigger pos Icon has 6pixel, 3 is a haft.
	for(int i=0; i<=GRID_WIDTH; i++) {
		/*Clear LCD buffer*/
		for (uint16_t k = 0; k < 2*201; k++)
		{
			LCD_Buffer[k] = 0x00;
		}
		if(peakA1<peakA2)
		{
			uint8_t tmp = peakA1;
			peakA1 = peakA2; peakA2 = tmp;
		}
		if(peakB1<peakB2)
		{
			uint8_t tmp = peakB1;
			peakB1 = peakB2; peakB2 = tmp;
		}
		// Tính phổ dB
		x = i * (xmax - xmin) / GRID_WIDTH + xmin;
		//x = exp((i - a) / b);
		pos1 = (uint16_t)round(x);

		uint16_t tmp = top;
		top    = bottom;
		bottom = tmp;
		for (int e = pos0; e <= pos1; e++)
		{
			if(Mag[e] > top)       top = Mag[e];
			if(Mag[e] < bottom) bottom = Mag[e];
		}
		pos0 = pos1;
		for (int y = bottom; y <= top; y++) {
			LCD_Buffer[2*y] = 0xf8;
			LCD_Buffer[2*y+1] = 0x00;
		}

		GRID_MARK(i);
		RenderLabels(i);
		//DRAW_WAVE_POS_ICON(i);
		LCD_FillBuffer(i, LCD_Buffer);
	}
}

void DRAW_FFT_info(void) {
	// Hiển thị tần số
	float frq = FFT.freq;
	const char* unit = "Hz";
	if (frq <= 0) {
		LCD_WriteString(220, 229, " ?Hz      ", Font_7x10, WHITE, BGR);
	} else {
		if (frq < 1000) {
			unit = "Hz ";
		} else if (frq < 1000000) {
			frq /= 1000.0;
			unit = "kHz";
		} else {
			frq /= 1000000.0;
			unit = "MHz";
		}
		printFloat(220, 229, frq, 7, 1, Font_7x10, WHITE, BGR);
		LCD_WriteString(269, 229, unit, Font_7x10, WHITE, BGR);
	}
	char c[20];
	double thd_percent = FFT.tdh;
	FormatNumberWithPrefixSuffix(thd_percent, false, 6, 2, "", "%", c);
	LCD_WriteString(40, 229, c, Font_7x10, WHITE, BGR);

	double cleanliness = FFT.sfdr;
	FormatNumberWithPrefixSuffix(cleanliness, false, 6, 3, "", "dBc", c);
	LCD_WriteString(141, 229, c, Font_7x10, WHITE, BGR);
}

#define SINC_WINDOW 10
#define SAMPLE_INTERVAL_NS 8.0f  // 125MSa/s

float sinc(float x) {
    if (x == 0.0f) return 1.0f;
    return sinf(M_PI * x) / (M_PI * x);
}

float sinc_interpolate_uint8(const uint8_t *samples, int num_samples, float t_ns) {
    float result = 0.0f;
    float t_index = t_ns / SAMPLE_INTERVAL_NS;
    int t_floor = (int)floorf(t_index);

    for (int n = -SINC_WINDOW; n <= SINC_WINDOW; ++n) {
        int idx = t_floor + n;
        if (idx >= 0 && idx < num_samples) {
            float x = t_index - idx;
            result += samples[idx] * sinc(x);
        }
    }
    return result;
}
