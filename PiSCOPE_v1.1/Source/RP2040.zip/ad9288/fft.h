#ifndef FFT_H
#define FFT_H
#include <stdbool.h>
#include <stdint.h>

#define FFT_SIZE 1024
#define M_PI 3.1415926535897932384626433832795

// Số lượng bin tần số đầu tiên cần bỏ qua để tránh DC và nhiễu tần số thấp.
// 5-10 là một giá trị khởi đầu tốt.
#define DC_IGNORE_BINS 5

// Độ rộng vùng cần loại trừ xung quanh đỉnh chính khi tìm hài.
// +/- 5 bin là đủ để loại bỏ toàn bộ "chân" của đỉnh chính.
#define PEAK_EXCLUSION_BINS 5
typedef struct {
    uint16_t Index;
    double   Amplitude;
} Harmonic_t;

extern double real[FFT_SIZE];
//extern double imag[FFT_SIZE];
extern double Mag[FFT_SIZE / 2 + 1];

void Split_Radix(int n, double ar[], double ai[]);
void fft_radix2_float(int n, double real[], double imag[]);
void RFFT(int N, bool dynamic, double CORRECTION_FACTOR, double *a);
void find_harmonics(int N, const double Mag[], Harmonic_t Harmonic[2]);
void fft_init(void);

#endif // FFT_H
