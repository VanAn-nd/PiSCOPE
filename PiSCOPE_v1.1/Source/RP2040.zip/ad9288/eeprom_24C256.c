#include "eeprom_24C256.h"
#include "pico/stdlib.h"
#include "hardware/i2c.h"
#include <string.h>

static uint16_t last_addr=0x0000;

static uint16_t write_ptr = CONFIG_BASE;

static struct {
    uint16_t counter;
    uint16_t addr;
} config_index[config_array_size];

void eeprom_init() {
    i2c_init(EEPROM_I2C_PORT, 400 * 1000);
    gpio_set_function(EEPROM_SDA_PIN, GPIO_FUNC_I2C);
    gpio_set_function(EEPROM_SCL_PIN, GPIO_FUNC_I2C);
    gpio_pull_up(EEPROM_SDA_PIN);
    gpio_pull_up(EEPROM_SCL_PIN);
}

bool eeprom_write_bytes(uint16_t addr, const uint8_t *data, size_t len) {
    uint8_t buf[len + 2];
    buf[0] = (addr >> 8) & 0xFF;
    buf[1] = addr & 0xFF;
    memcpy(&buf[2], data, len);
    
    int res = i2c_write_blocking(EEPROM_I2C_PORT, EEPROM_I2C_ADDR, buf, len + 2, false);
    sleep_ms(6); // wait for EEPROM internal write
    return res == (len + 2);
}

bool eeprom_read_bytes(uint16_t addr, uint8_t *buffer, size_t len) {
    uint8_t addr_buf[2] = { (addr >> 8) & 0xFF, addr & 0xFF };
    if (i2c_write_blocking(EEPROM_I2C_PORT, EEPROM_I2C_ADDR, addr_buf, 2, true) != 2) return false;
    int res = i2c_read_blocking(EEPROM_I2C_PORT, EEPROM_I2C_ADDR, buffer, len, false);
    return res == (int)len;
}

uint8_t crc8(const uint8_t *data, size_t length) {
    //CRC-8/ITU:
    uint8_t polynomial    = 0x07;
    uint8_t initial_value = 0x00;

    uint8_t crc = initial_value;
    for (size_t i = 0; i < length; i++) {
        crc ^= data[i];
        for (int j = 0; j < 8; j++) {
            if (crc & 0x80) {
                crc = (crc << 1) ^ polynomial;
            } else {
                crc <<= 1;
            }
        }
    }
    return crc;
}

bool eeprom_read_config_byte(uint16_t addr, uint8_t *config_id, uint8_t *data) {
    ConfigBlock block;
    if (!eeprom_read_bytes(addr, (uint8_t*)&block, BLOCK_SIZE)) return false;

    if (block.marker != MARKER_COMMITTED) return false;  // chỉ chấp nhận block hợp lệ
    if (crc8((uint8_t*)&block, 5) != block.checksum) return false;  // kiểm tra CRC

    *config_id = block.id;
    *data = block.data;
    return true;
}

bool eeprom_write_config_byte(uint16_t addr, uint8_t config_id, uint8_t data) {
    ConfigBlock block;
    block.marker = MARKER_COMMITTED;          // trạng thái "đang ghi"
    block.id = config_id;
    block.data = data;
    block.sequence = 5;
    block.checksum = crc8((uint8_t*)&block, 5);  // CRC của magic, id, data

    uint8_t temp_block[sizeof(block)];
    memcpy(temp_block, &block, sizeof(block));
    temp_block[0] = MARKER_PENDING;        // Thay marker thành "đang ghi" tạm thời

    // Ghi block với magic = STATUS_PENDING
    if (!eeprom_write_bytes(addr, temp_block, sizeof(block))) return false;

    // Sau đó ghi lại byte đầu tiên (magic) thành STATUS_COMMITTED
    uint8_t valid_magic = MARKER_COMMITTED;
    return eeprom_write_bytes(addr, &valid_magic, 1);
}

uint16_t eeprom_write_block(uint8_t config_id, uint8_t data) {
    if (last_addr + BLOCK_SIZE > EEPROM_SIZE) {
        // Đã ghi hết EEPROM, quay về đầu (wear leveling vòng tròn)
        last_addr = 0;
    }

    uint16_t ad;
    uint8_t st = eeprom_write_config_byte(last_addr, config_id, data);
    if(st) {ad = last_addr; last_addr += BLOCK_SIZE;}

    return ad;
}

bool eeprom_read_all_configs(uint8_t configs[config_array_size]) {
    // Khởi tạo danh sách config (mặc định: không hợp lệ)
    for (int i = 0; i < config_array_size; ++i) {
        configs[i] = 0;
    }
    last_addr = 0;
    while (last_addr + BLOCK_SIZE <= EEPROM_SIZE)
    {
		ConfigBlock block;
        if (!eeprom_read_bytes(last_addr, (uint8_t*)&block, BLOCK_SIZE)) return false;

        // Kiểm tra magic byte
		if (block.marker != MARKER_COMMITTED) {
			last_addr += BLOCK_SIZE;
			continue;
		}

		// Kiểm tra CRC
		uint8_t calc_crc = crc8((uint8_t*)&block, 5);
		if (calc_crc != block.checksum) {
			last_addr += BLOCK_SIZE;
			continue;
		}

        // Bảo vệ giới hạn mảng
		if (block.id >= 0 && block.id < config_array_size) {
			configs[block.id] = block.data;
		}
        last_addr += BLOCK_SIZE;
    }
}






// === Tránh ghi đè lên block mới nhất của bất kỳ ID nào ===
static void skip_protected_blocks() {
    bool conflict;
    do {
        conflict = false;
        for (int i = 0; i < config_array_size; i++) {
            if (config_index[i].addr == write_ptr) {
                write_ptr += BLOCK_SIZE;
                if (write_ptr >= EEPROM_SIZE) write_ptr = CONFIG_BASE;
                conflict = true;
                break; // Restart check
            }
        }
    } while (conflict);
}

uint16_t eeprom_write_new_block(uint8_t config_id, uint8_t data) {
    if (config_id >= config_array_size) return false;

    ConfigBlock blk;

    blk.marker = MARKER_COMMITTED;  // CRC sẽ tính theo marker này
    blk.id = config_id;
    blk.data = data;
    blk.sequence = config_index[config_id].counter + 1;
    blk.checksum = crc8((uint8_t*)&blk, 5);  // CRC của magic, id, data

    // Tránh ghi đè block mới nhất
    skip_protected_blocks();

    uint8_t temp_block[sizeof(blk)];
    memcpy(temp_block, &blk, sizeof(blk));
    temp_block[0] = MARKER_PENDING;        // Thay marker thành "đang ghi" tạm thời

    // Ghi block với magic = STATUS_PENDING
    if (!eeprom_write_bytes(write_ptr, temp_block, sizeof(blk))) return 0xFFFF;//false

    // Sau đó ghi lại byte đầu tiên (magic) thành STATUS_COMMITTED
    uint8_t valid_magic = MARKER_COMMITTED;
    if (!eeprom_write_bytes(write_ptr, &valid_magic, 1)) return 0xFFFF;//false

    // Cập nhật index
    config_index[config_id].counter = blk.sequence;
    config_index[config_id].addr = write_ptr;

    // Tiến con trỏ ghi
    write_ptr += BLOCK_SIZE;
    if (write_ptr >= EEPROM_SIZE) write_ptr = CONFIG_BASE;

    return write_ptr-BLOCK_SIZE;
}


// === Đọc block mới nhất theo ID ===
bool eeprom_wl_read_latest(uint8_t id, ConfigBlock *out) {
    if (id >= config_array_size || config_index[id].counter == 0) return false;

    eeprom_read_bytes(config_index[id].addr, (uint8_t *)out, BLOCK_SIZE);
    return true;
}

uint16_t eeprom_wl_init(uint8_t configs[config_array_size]) {
    /*
    i2c_init(EEPROM_I2C_PORT, 400 * 1000);
    gpio_set_function(EEPROM_I2C_SDA, GPIO_FUNC_I2C);
    gpio_set_function(EEPROM_I2C_SCL, GPIO_FUNC_I2C);
    gpio_pull_up(EEPROM_I2C_SDA);
    gpio_pull_up(EEPROM_I2C_SCL);
    */
    memset(config_index, 0, sizeof(config_index));
    write_ptr = CONFIG_BASE;

    ConfigBlock blk;

    for (uint16_t addr = CONFIG_BASE; addr < EEPROM_SIZE; addr += BLOCK_SIZE) {
        eeprom_read_bytes(addr, (uint8_t *)&blk, BLOCK_SIZE);

        if (blk.marker != MARKER_COMMITTED) continue;
        if (blk.id >= config_array_size) continue;
        if (crc8((uint8_t *)&blk, 5) != blk.checksum) continue;

        if (blk.sequence > config_index[blk.id].counter) {
            config_index[blk.id].counter = blk.sequence;
            config_index[blk.id].addr = addr;
            configs[blk.id] = blk.data;
        }
        write_ptr = addr + BLOCK_SIZE;
        if (write_ptr >= EEPROM_SIZE) write_ptr = CONFIG_BASE;
    }
    return write_ptr-BLOCK_SIZE;
}




